# Technical Notes: OpenCV Integration with See3CAM Cameras (e-con Systems)

**IMPORTANT NOTE FOR PROJECT HANDOVER:**

This document details the technical challenges and solutions encountered specifically during the integration of **OpenCV (version 4.5.5 referenced herein) with See3CAM (e-con Systems) cameras on a Windows environment, often requiring a custom OpenCV build.**

-   **Relevance:** These notes are CRITICAL if you intend to use See3CAM cameras with a similar custom-built OpenCV. The procedures for custom `videoio` modules, DirectShow filters (`Y8GrabberFilter.dll`), and specific CMake flags are likely still relevant for that hardware.
-   **If NOT using See3CAM:** If you are using standard webcams or different camera hardware, much of the OpenCV custom build process detailed here (especially e-con Systems specific `videoio` and filters) may NOT be necessary. Standard `opencv-python` from PyPI might suffice (see main `README.md` for general setup).
-   **Version Discrepancy:** Note that this document refers to **OpenCV 4.5.5 and NumPy 1.23.5**. The main project `README.md` and `requirements.txt` may reference newer versions (e.g., OpenCV 4.7.0 and NumPy 1.22.0). **Please verify the currently targeted/supported versions for the overall project.** These notes might reflect an earlier development phase or a specific branch of work.
-   **Hardcoded Paths:** Any absolute file paths shown in examples (e.g., in `config-3.11.py` snippets) are illustrative and **MUST BE ADAPTED** to your specific system environment.

This document provides technical details about the integration of OpenCV with See3CAM cameras and the solutions to challenges encountered.

## Table of Contents

1. [Core Issues Encountered](#core-issues-encountered)
2. [OpenCV Build Process](#opencv-build-process)
3. [Python Binding Configuration](#python-binding-configuration)
4. [Camera Detection Solutions](#camera-detection-solutions)
5. [Performance Considerations](#performance-considerations)
6. [Debugging Techniques](#debugging-techniques)

## Core Issues Encountered

### Issue 1: OpenCV Modules Not Loading

**Symptom**: OpenCV would import but core functions like `cvtColor`, `imread`, and `VideoCapture` were missing or resulted in errors.

**Root Cause**: The Python module (`cv2.pyd`) was found, but it couldn't correctly load its dependent compiled C++ libraries (e.g., `opencv_world<version>.dll`). This can be due to missing DLLs in PATH, ABI incompatibilities (often with NumPy), or incorrect build configurations.

**Solution (for the specific case encountered with OpenCV 4.5.5)**:
1. Installing a **compatible version of NumPy (e.g., 1.23.5 was noted for OpenCV 4.5.5)**. ABI (Application Binary Interface) compatibility between NumPy and the OpenCV Python bindings is crucial.
2. Ensuring the compiled OpenCV DLLs (e.g., `opencv_world455.dll`) were accessible by Python. This could involve:
    a. Placing them in a directory included in the system's PATH environment variable.
    b. Copying the DLLs directly to the Python `site-packages` directory (less ideal but can work as a quick fix).
    c. For some Python versions/OpenCV builds, a `cv2/config-<python_version>.py` file might be used by OpenCV to help locate binaries (see Python Binding Configuration section).

### Issue 2: Camera Not Being Detected (Especially See3CAM)

**Symptom**: While a basic test script (`test_camera.py`) might detect and use the camera, the main application (`poc_shaily_enhanced.py` or other scripts) couldn't access it.

**Root Cause**: Different camera initialization code. The working script likely explicitly used the **DirectShow backend (`cv2.CAP_DSHOW`)**, which is often necessary for specialized/industrial cameras like See3CAM on Windows to be correctly enumerated and controlled, whereas default OpenCV `VideoCapture(0)` might use Media Foundation or VFW which may not support all features of such cameras.

**Solution**: Update the camera detection and initialization functions in all relevant scripts to consistently use `cv2.VideoCapture(camera_idx, cv2.CAP_DSHOW)` when See3CAM or similar specialized cameras are targeted on Windows.

### Issue 3: Character Encoding in Config Files

**Symptom**: Import errors related to invalid characters in configuration files.

**Root Cause**: The configuration files were being saved with a BOM (Byte Order Mark) or in non-UTF-8 encoding.

**Solution**: We recreated the configuration files with proper UTF-8 encoding without BOM.

## OpenCV Build Process

Building OpenCV with e-con Systems See3CAM camera support requires several specific steps beyond a standard OpenCV build. These steps typically aim to incorporate e-con Systems' specific `videoio` module and DirectShow filters.

**Note:** The following refers to a custom build process. The exact source for e-con Systems' modified OpenCV components (`econsystems_temp\econsystems_opencv\Source\videoio`) would need to be obtained from e-con Systems if not already part of this project's private resources.

### 1. Custom VideoIO Module (e-con Systems Specific)

The standard OpenCV `videoio` module may lack optimized or full support for e-con Systems cameras. A customized version provided by e-con Systems might be used:

```cmd
REM Example: xcopy /E /I /Y path\to\econsystems_opencv_videoio_source modules\videoio
```
This command implies replacing the standard `modules/videoio` in the OpenCV source tree with the one from e-con Systems before building.

### 2. PkgConfig Dependency Issue (Common in Windows Builds)

The e-con Systems modified `videoio` module (or standard OpenCV when certain features are enabled) might have a dependency on PkgConfig for locating libraries like FFMPEG and libudev. PkgConfig is not standard on Windows.

**Fixed by (common approaches)**:
- Modifying the `modules/videoio/CMakeLists.txt` to remove or make optional the PkgConfig dependencies if they are not strictly needed for See3CAM DirectShow support.
- Setting CMake flags to disable features that pull in these dependencies if those features (like FFMPEG or GStreamer for general video file handling) are not required for the core See3CAM functionality:
  `-DWITH_FFMPEG=OFF -DWITH_GSTREAMER=OFF`

### 3. DirectShow Dependencies (Windows SDK)

For proper DirectShow support in the OpenCV build, ensure the Windows SDK is installed and CMake can find necessary DirectShow libraries. Sometimes, these need to be explicitly linked:

```cmake
# Example CMake directive if auto-linking fails:
# TARGET_LINK_LIBRARIES(opencv_videoio PRIVATE setupapi strmiids)
# Or via CMake definitions in build script: -DOPENCV_LINKER_LIBS="setupapi.lib;strmiids.lib" (syntax might vary)
```

### 4. Y8GrabberFilter Registration (e-con Systems Specific)

See3CAM cameras often use a custom DirectShow filter, like `Y8GrabberFilter.dll`, for raw Y8 video format, which needs to be registered in the system:

```cmd
REM Ensure you have admin rights for this command
regsvr32 "C:\path\to\your\driver\installation\Y8GrabberFilter.dll"
```
**The path to `Y8GrabberFilter.dll` depends on the See3CAM driver/SDK installation.**

## Python Binding Configuration

Ensuring the Python bindings (`cv2` module) work correctly after a custom OpenCV build, especially with specific hardware dependencies.

### 1. Compatible NumPy Version

As noted, OpenCV Python bindings have tight ABI compatibility with NumPy. For the **OpenCV 4.5.5** build referenced in these notes, **NumPy 1.23.5** or earlier was found necessary. **Verify against the target OpenCV version for the current project.**

```bash
REM Example: pip install numpy==1.23.5
```

### 2. Configuration File (cv2.config.py or similar)

In some OpenCV Python builds, a `cv2.config-<python_version>.py` file (e.g., `config-3.11.py` for Python 3.11) or `cv2/__init__.py` modifications might be used to help the Python interpreter locate the compiled OpenCV DLLs, especially if they are not in the system PATH or standard library locations.

**The example below shows hardcoded paths and is NOT recommended for portable deployment. Use environment variables or ensure DLLs are in PATH.**
```python
# Example snippet that might be in a cv2 config helper (highly system-specific)
# import os
# BINARIES_PATHS = [
#     'C:/Users/shaily/Documents/NJIT/Brian/opencv_build/opencv/build/bin/Release', # Path to custom build binaries
#     # Add other relevant paths if necessary
# ]
# for p in BINARIES_PATHS:
#    if os.path.isdir(p):
#        os.add_dll_directory(p) # Python 3.8+ way to add DLL search paths
```

### 3. DLL Placement (If not using `add_dll_directory` or PATH setup)

As a last resort, or during development, copying the main OpenCV DLL (e.g., `opencv_world455.dll` for a monolithic build, or individual module DLLs) to the Python `site-packages` directory (where `cv2.pyd` resides) can sometimes resolve loading issues. This is generally not a good practice for deployment.

```cmd
REM Example: copy "build\bin\Release\opencv_world455.dll" .venv\Lib\site-packages\
```

## Camera Detection Solutions

### Using DirectShow Backend

The key to detecting specialized cameras like See3CAM is using the DirectShow backend:

```python
cap = cv2.VideoCapture(camera_idx, cv2.CAP_DSHOW)
```

### Proper Camera Enumeration

Our solution enumerates cameras systematically and provides detailed information:

```python
def list_available_cameras(max_to_check=5):
    """List all available camera indices and let user choose one."""
    available_cameras = []
    print(f"Probing up to {max_to_check} camera indices...")
    for i in range(max_to_check): 
        try:
            print(f"Checking camera index: {i}...")
            # Use DirectShow backend, which is better for specialized cameras like See3CAM on Windows.
            # For standard webcams or other OS, cv2.CAP_DSHOW might not be needed or available.
            cap = cv2.VideoCapture(i, cv2.CAP_DSHOW)
            if cap.isOpened():
                ret, _ = cap.read()
                if ret:
                    # Store additional information about the camera
                    available_cameras.append({
                        'index': i,
                        'resolution': (int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)), 
                                      int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))),
                        'fps': cap.get(cv2.CAP_PROP_FPS) # Note: FPS reported here can sometimes be nominal.
                    })
                    print(f"  Camera {i} opened successfully.")
                else:
                    print(f"  Camera {i} opened but failed to read a frame.")
            else:
                print(f"  Camera {i} could not be opened.")
            cap.release() # Crucial to release the camera here
            time.sleep(0.1)  # Small delay to allow resources to be fully released.
        except Exception as e:
            print(f"Error checking camera {i}: {str(e)}")
    if not available_cameras:
        print("No usable cameras found with DirectShow backend.")
    return available_cameras
```

### Camera Release Timing

When enumerating multiple cameras or rapidly opening/closing a camera, it's crucial to `cap.release()` the `VideoCapture` object. Adding a small `time.sleep(0.1)` after release can sometimes help ensure system resources are freed before the next attempt, especially with certain drivers or backends.

```python
# cap.release()
# time.sleep(0.1)  # Give the camera system time to release resources
```

## Performance Considerations

### Frame Processing

For optimal performance when processing frames:

1. **Resize for Consistency**: Using `imutils.resize()` ensures consistent frame sizes while maintaining aspect ratio.

2. **HSV Color Conversion**: Converting to HSV color space provides more robust color-based object detection.

3. **Morphological Operations**: Using erosion and dilation helps remove noise and fill gaps:
   ```python
   mask = cv2.erode(mask, None, iterations=2)
   mask = cv2.dilate(mask, None, iterations=2)
   ```

### Real-time FPS Calculation

Instead of hard-coding frame rates, we calculate actual FPS in real-time:

```python
current_time = time.time()
dt = current_time - prev_time
prev_time = current_time
actual_fps = 1.0 / dt if dt > 0 else 0
```

## Debugging Techniques

### Testing OpenCV Installation

Our test script (`test_opencv_final.py`) provides a systematic way to verify OpenCV functionality:

1. Checks if OpenCV can be imported
2. Verifies the version information
3. Tests basic image operations (create, convert)
4. Lists available functions
5. Reports detailed attributes

### Camera Testing

The dedicated camera test script (`test_camera.py`) helps isolate camera-specific issues:

1. Checks which cameras are available
2. Reports camera properties (resolution, FPS)
3. Attempts to capture and display frames
4. Uses same DirectShow backend as the main application

### DirectShow Filter Verification (For See3CAM)

To verify DirectShow filters (like `Y8GrabberFilter.dll`) are registered and available on Windows:
- Use tools like GraphEdit, GraphEditPlus, or GraphStudioNext to visually inspect the DirectShow filter graph when the camera is active.
- Check the Windows Registry for the filter's CLSID (Class ID). The CLSID provided `{39ea834f-2c39-470f-803a-cc75fcb12aa8}` would be specific to a particular version/filter; verify with e-con Systems documentation.
  Example (run in `cmd`):
  `reg query "HKLM\SOFTWARE\Classes\CLSID\{YOUR_FILTER_CLSID_HERE}"`

## References and Resources

1. [e-con Systems GitHub (if available for specific OpenCV versions/patches)](https://github.com/econsystems/opencv) - Link might be example, verify actual source for e-con specific code.
2. [OpenCV Official Documentation](https://docs.opencv.org/) - Refer to version matching your build.
3. [Microsoft DirectShow Documentation](https://docs.microsoft.com/en-us/windows/win32/directshow/directshow)
4. [See3CAM Camera Series Documentation](https://www.e-consystems.com/See3CAM-USB-3-Camera.asp) - Consult for specific models and driver information. 