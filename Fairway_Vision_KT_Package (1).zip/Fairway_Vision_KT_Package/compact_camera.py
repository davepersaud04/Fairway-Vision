import cv2
import numpy as np
import threading
import time
import logging
from collections import deque

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class CompactCamera:
    """
    Camera interface optimized for smart glasses with limited resources.
    This class handles camera initialization, frame acquisition, and basic image processing
    in a resource-efficient manner suitable for embedded systems.

    Author: Shaily
    """
    
    def __init__(self, camera_index=0, resolution=(640, 480), fps=30, buffer_size=5):
        self.camera_index = camera_index
        self.resolution = resolution
        self.fps = fps
        self.buffer_size = buffer_size
        
        # Frame storage with timestamps
        self.frame_buffer = deque(maxlen=buffer_size)
        
        # Camera properties
        self.camera = None
        self.is_running = False
        self.thread = None
        
        # Performance monitoring
        self.actual_fps = 0 # FPS of the capture loop
        self.capture_loop_processing_times = deque(maxlen=30)  # Stores processing times for the _capture_loop itself
        self.detection_processing_times = deque(maxlen=30) # Stores processing times for the detect_ball method
        
        # Ball detection settings optimized for efficiency
        # These HSV values are calibrated for specific lighting conditions and ball colors.
        # They might need recalibration for different environments.
        self.ball_color = 'white'  # Default target color
        self.hsv_lower = np.array([0, 0, 200])    # Lower HSV threshold for white
        self.hsv_upper = np.array([179, 30, 255]) # Upper HSV threshold for white
        self.min_ball_size = 5  # Minimum radius in pixels for a detected ball to be considered valid.
        
        # Detection results
        self.last_detection = None # Stores the full detection dictionary
        self.detection_confidence = 0.0
        
    def start(self):
        """Initialize and start the camera capturing thread."""
        try:
            # Try to open camera with most efficient parameters for smart glasses
            self.camera = cv2.VideoCapture(self.camera_index)
            
            # Configure camera for efficiency
            self.camera.set(cv2.CAP_PROP_FRAME_WIDTH, self.resolution[0])
            self.camera.set(cv2.CAP_PROP_FRAME_HEIGHT, self.resolution[1])
            self.camera.set(cv2.CAP_PROP_FPS, self.fps)
            
            # Reduce buffer size to minimize latency
            self.camera.set(cv2.CAP_PROP_BUFFERSIZE, 1)
            
            # Check if camera opened successfully
            if not self.camera.isOpened():
                logger.error(f"Failed to open camera {self.camera_index}")
                return False
            
            # Start capture thread
            self.is_running = True
            self.thread = threading.Thread(target=self._capture_loop)
            self.thread.daemon = True  # Thread will exit when main program exits
            self.thread.start()
            
            logger.info(f"Camera started successfully: {self.resolution[0]}x{self.resolution[1]} @ {self.fps}fps")
            return True
            
        except Exception as e:
            logger.error(f"Failed to start camera: {str(e)}")
            return False
    
    def stop(self):
        """Stop the camera and release resources."""
        self.is_running = False
        if self.thread is not None:
            self.thread.join(timeout=1.0)
        
        if self.camera is not None:
            self.camera.release()
            self.camera = None
        
        logger.info("Camera stopped and resources released")
    
    def _capture_loop(self):
        """Main camera capture loop that runs in a separate thread to continuously acquire frames."""
        frame_count = 0
        start_time = time.time()
        
        while self.is_running:
            loop_start_time = time.time()
            
            # Capture frame from the camera
            ret, frame = self.camera.read()
            
            if ret:
                # Store frame with timestamp
                timestamp = time.time()
                self.frame_buffer.append((frame, timestamp))
                
                # Update FPS calculation every 10 frames
                frame_count += 1
                if frame_count % 10 == 0:
                    end_time = time.time()
                    self.actual_fps = 10 / (end_time - start_time)
                    start_time = end_time
                    
                    # Log performance stats occasionally
                    if frame_count % 30 == 0:
                        avg_capture_loop_time = np.mean(self.capture_loop_processing_times) if self.capture_loop_processing_times else 0
                        avg_detection_time = np.mean(self.detection_processing_times) if self.detection_processing_times else 0
                        logger.debug(f"Camera Perf: Actual {self.actual_fps:.1f} FPS, " 
                                    f"Capture Loop Time: {avg_capture_loop_time*1000:.1f}ms, "
                                    f"Avg Detection Time: {avg_detection_time*1000:.1f}ms")
            else:
                logger.warning("Failed to capture frame from camera.")
                time.sleep(0.01)  # Short sleep to prevent CPU overuse on persistent capture failure
            
            # Calculate processing time for this iteration of the capture loop
            current_loop_processing_time = time.time() - loop_start_time
            self.capture_loop_processing_times.append(current_loop_processing_time)
            
            # If the capture loop is running faster than the target FPS, sleep to conserve resources.
            # This is particularly important for embedded systems to manage power consumption.
            target_frame_time = 1.0 / self.fps
            if current_loop_processing_time < target_frame_time:
                time.sleep(target_frame_time - current_loop_processing_time)
    
    def get_latest_frame(self):
        """Get the most recent frame and its timestamp."""
        if not self.frame_buffer:
            return None, None
        
        return self.frame_buffer[-1]
    
    def get_frame_sequence(self, count=None):
        """Get a sequence of the most recent frames and their timestamps."""
        if not self.frame_buffer:
            return []
        
        if count is None or count >= len(self.frame_buffer):
            return list(self.frame_buffer)
        else:
            return list(self.frame_buffer)[-count:]
    
    def set_ball_color(self, color):
        """
        Set the target ball color and update HSV thresholds accordingly.
        These thresholds are examples and may need tuning for optimal performance under various lighting.
        """
        self.ball_color = color
        logger.info(f"Setting ball color for detection to: {color}")
        
        # Update HSV thresholds based on selected color
        # Format: [Hue, Saturation, Value]
        if color == 'white':
            # For white balls: wide Hue range, low Saturation, high Value.
            self.hsv_lower = np.array([0, 0, 180]) # Adjusted lower Value for more robustness
            self.hsv_upper = np.array([179, 50, 255])# Adjusted upper Saturation slightly
        elif color == 'yellow':
            # For yellow balls: specific Hue range for yellow, moderate to high Saturation and Value.
            self.hsv_lower = np.array([20, 100, 100])
            self.hsv_upper = np.array([35, 255, 255]) # Narrowed Hue range for yellow
        elif color == 'orange':
            # For orange balls: specific Hue range for orange.
            self.hsv_lower = np.array([5, 100, 100])
            self.hsv_upper = np.array([20, 255, 255]) # Adjusted Hue range for orange
        else:
            logger.warning(f"Unknown ball color: {color}, defaulting to white")
            self.hsv_lower = np.array([0, 0, 200])
            self.hsv_upper = np.array([179, 30, 255])
    
    def detect_ball(self, frame=None):
        """
        Detect a golf ball in the provided frame or latest frame.
        Optimized for efficiency on resource-constrained devices.
        """
        detection_start = time.time()
        
        # Use provided frame or get latest frame
        if frame is None:
            frame_data = self.get_latest_frame()
            if frame_data[0] is None:
                return None, 0
            frame, timestamp = frame_data
        
        # Create smaller copy for processing (improves performance)
        small_frame = cv2.resize(frame, (320, 240))
        
        # Convert to HSV colorspace
        hsv = cv2.cvtColor(small_frame, cv2.COLOR_BGR2HSV)
        
        # Create mask based on the selected HSV color range
        mask = cv2.inRange(hsv, self.hsv_lower, self.hsv_upper)
        
        # Noise reduction using morphological operations.
        # Erode to remove small noise, Dilate to restore/enhance larger objects.
        # Iterations depend on noise level and object size; these are common starting points.
        mask = cv2.erode(mask, None, iterations=1)
        mask = cv2.dilate(mask, None, iterations=2)
        
        # Find contours in the mask. RETR_EXTERNAL gets only outer contours.
        # CHAIN_APPROX_SIMPLE compresses contour segments, saving memory.
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        # If no contours found, return early
        if not contours:
            self.last_detection = None
            self.detection_confidence = 0.0
            return None, 0
        
        # Find the best contour based on simplified circularity calculation
        best_contour = None
        best_score = 0
        
        for c in contours:
            # Get area - quick filtering for very small, noisy contours.
            # This threshold (30 pixels) is empirical and might need adjustment.
            area = cv2.contourArea(c)
            if area < 30:  # Heuristic: skip tiny contours likely to be noise
                continue
                
            # Calculate perimeter for circularity
            perimeter = cv2.arcLength(c, True)
            if perimeter <= 0:
                continue
                
            circularity = 4 * np.pi * area / (perimeter * perimeter)
            
            # Simple weighted score: combines circularity and area.
            # Larger, more circular objects get higher scores.
            # This scoring is a heuristic; more sophisticated methods could be used.
            score = circularity * (area / 100.0) # Ensure float division
            
            if score > best_score:
                best_score = score
                best_contour = c
        
        # If a good contour is found based on the score threshold.
        # The threshold (0.4) is empirical and determines detection sensitivity.
        if best_contour is not None and best_score > 0.4: # Heuristic score threshold
            # Get minimum enclosing circle for the best contour
            ((x, y), radius) = cv2.minEnclosingCircle(best_contour)
            
            # Scale coordinates back to original frame size
            scale_x = frame.shape[1] / small_frame.shape[1]
            scale_y = frame.shape[0] / small_frame.shape[0]
            
            center_x = int(x * scale_x)
            center_y = int(y * scale_y)
            radius = int(radius * scale_x)  # Use x scale for radius
            
            # Only consider if radius is large enough
            if radius >= self.min_ball_size:
                detection = {
                    'center': (center_x, center_y),
                    'radius': radius,
                    'confidence': min(1.0, best_score),
                    'timestamp': time.time()
                }
                
                self.last_detection = detection
                self.detection_confidence = detection['confidence']
                
                # Track processing time for the detection operation itself
                detection_processing_time = time.time() - detection_start
                self.detection_processing_times.append(detection_processing_time)
                
                return detection, detection['confidence']
        
        # No valid ball found
        self.last_detection = None
        self.detection_confidence = 0.0
        return None, 0
    
    def get_camera_info(self):
        """Get information about the current camera state."""
        if not self.camera or not self.camera.isOpened():
            return "Camera not initialized"
            
        actual_width = int(self.camera.get(cv2.CAP_PROP_FRAME_WIDTH))
        actual_height = int(self.camera.get(cv2.CAP_PROP_FRAME_HEIGHT))
        actual_fps_val = self.camera.get(cv2.CAP_PROP_FPS)
        
        # Calculate battery impact estimate (simplified heuristic)
        # More sophisticated power modeling would be needed for accurate battery life prediction.
        battery_impact_str = "Low"
        if self.resolution[0] * self.resolution[1] > 640*480:
            battery_impact_str = "Medium"
        if self.resolution[0] * self.resolution[1] > 1280*720 or self.fps > 30:
            battery_impact_str = "High"
        
        avg_capture_loop_time = np.mean(self.capture_loop_processing_times) if self.capture_loop_processing_times else 0
        avg_detection_time = np.mean(self.detection_processing_times) if self.detection_processing_times else 0
        
        return {
            "requested_resolution": f"{self.resolution[0]}x{self.resolution[1]}",
            "actual_resolution": f"{actual_width}x{actual_height}",
            "requested_fps": self.fps,
            "reported_camera_fps": f"{actual_fps_val:.1f}", # FPS reported by camera driver
            "capture_loop_fps": f"{self.actual_fps:.1f}",    # FPS achieved by our capture loop
            "frame_buffer_status": f"{len(self.frame_buffer)}/{self.buffer_size}",
            "avg_capture_loop_time_ms": f"{avg_capture_loop_time*1000:.1f}",
            "avg_detection_time_ms": f"{avg_detection_time*1000:.1f}",
            "estimated_battery_impact": battery_impact_str,
            "last_detection_confidence": f"{self.detection_confidence:.2f}"
        }


class SmartGlassesSim:
    """
    Simulates a smart glasses system with integrated camera and ball tracking.
    This would interface with actual smart glasses hardware in production.
    """
    
    def __init__(self, camera_index=0):
        # Initialize the camera subsystem
        self.camera = CompactCamera(camera_index=camera_index)
        
        # System state
        self.is_running = False
        self.is_tracking = False
        self.power_mode = "balanced"  # balanced, performance, or power-saving
        
        # Ball tracking data
        self.ball_positions = deque(maxlen=30)  # Recent ball positions
        self.last_update_time = None
        
    def start(self):
        """Start the smart glasses system."""
        if self.camera.start():
            self.is_running = True
            self.last_update_time = time.time()
            logger.info("Smart glasses system started successfully")
            return True
        else:
            logger.error("Failed to start smart glasses system")
            return False
    
    def stop(self):
        """Stop the smart glasses system."""
        self.is_running = False
        self.camera.stop()
        logger.info("Smart glasses system stopped")
    
    def set_power_mode(self, mode):
        """Set the power mode of the system."""
        valid_modes = ["balanced", "performance", "power-saving"]
        if mode not in valid_modes:
            logger.warning(f"Invalid power mode: {mode}. Using 'balanced'.")
            mode = "balanced"
        
        self.power_mode = mode
        
        # Adjust camera parameters based on power mode
        if mode == "balanced":
            self.camera.resolution = (640, 480)
            self.camera.fps = 30
        elif mode == "performance":
            self.camera.resolution = (1280, 720)
            self.camera.fps = 60
        elif mode == "power-saving":
            self.camera.resolution = (320, 240)
            self.camera.fps = 15
        
        logger.info(f"Power mode set to {mode}")
    
    def track_ball(self):
        """Track the ball in the latest frame."""
        if not self.is_running:
            return None
        
        frame, timestamp = self.camera.get_latest_frame()
        if frame is None:
            return None
        
        # Detect the ball in the current frame
        detection, confidence = self.camera.detect_ball(frame)
        
        if detection:
            self.is_tracking = True
            self.ball_positions.append((detection['center'], timestamp))
            return detection
        else:
            # Ball not found in this frame
            if self.is_tracking:
                # If we were tracking before, add None to maintain sequence
                self.ball_positions.append((None, timestamp))
                
                # Check if we've lost tracking for a certain number of consecutive frames
                # This '10' is a heuristic for how long to wait before declaring tracking fully lost.
                if len([p for p in self.ball_positions if p[0] is None]) > 10:
                    self.is_tracking = False
                    logger.info("Ball tracking lost (too many consecutive missed detections).")
            
            return None
    
    def get_status(self):
        """Get the current status of the smart glasses system."""
        camera_info = self.camera.get_camera_info()
        
        return {
            "system_status": "running" if self.is_running else "stopped",
            "tracking_status": "active" if self.is_tracking else "inactive",
            "power_mode": self.power_mode,
            "estimated_battery_impact": camera_info.get("estimated_battery_impact", "N/A"), # Use .get for safety
            "camera_details": camera_info, # Nested dictionary for all camera specific info
            "tracked_positions_in_deque": len([p for p in self.ball_positions if p[0] is not None]),
            "fps_capture_loop": camera_info.get("capture_loop_fps", "N/A") # Use .get for safety
        }
    
    def get_ball_trajectory_data(self):
        """Get the ball trajectory data for prediction."""
        if not self.ball_positions:
            return []
        
        # Filter out None positions
        valid_positions = [p for p in self.ball_positions if p[0] is not None]
        
        if not valid_positions:
            return []
            
        return valid_positions


# Example usage
if __name__ == "__main__":
    # Create and start the smart glasses simulation
    glasses = SmartGlassesSim(camera_index=0)
    
    if glasses.start():
        try:
            # Set to power-saving mode for embedded device
            glasses.set_power_mode("balanced")
            
            # Run for 100 frames or until interrupted
            for _ in range(100):
                # Track the ball
                detection = glasses.track_ball()
                
                # Get the latest frame
                frame, _ = glasses.camera.get_latest_frame()
                
                if frame is not None:
                    # Draw detection if available
                    if detection:
                        center = detection['center']
                        radius = detection['radius']
                        cv2.circle(frame, center, radius, (0, 255, 0), 2)
                        cv2.circle(frame, center, 2, (0, 0, 255), -1)
                    
                    # Draw system status
                    status = glasses.get_status()
                    text = f"Mode: {status['power_mode']} | FPS: {status['fps_capture_loop']}"
                    cv2.putText(frame, text, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)
                    
                    tracking_text = f"Tracking: {'Yes' if detection else 'No'} | Conf: {glasses.camera.detection_confidence:.2f}"
                    cv2.putText(frame, tracking_text, (10, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)
                    
                    # Display actual camera resolution from CompactCamera info
                    cam_info = glasses.camera.get_camera_info()
                    res_text = f"Res: {cam_info.get('actual_resolution', 'N/A')}"
                    cv2.putText(frame, res_text, (10, 90), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)
                    
                    # Show the frame
                    cv2.imshow("Smart Glasses View", frame)
                    
                    # Check for key press to exit
                    if cv2.waitKey(1) & 0xFF == ord('q'):
                        break
                
                time.sleep(0.01)  # Small sleep to prevent CPU hogging
                
        except KeyboardInterrupt:
            print("Interrupted by user")
        finally:
            # Clean up
            glasses.stop()
            cv2.destroyAllWindows()
    else:
        print("Failed to start smart glasses simulation") 