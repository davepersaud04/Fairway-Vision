import cv2
import numpy as np
import time
import argparse
import threading
import logging
import os
import json
from collections import deque
import matplotlib.pyplot as plt
from datetime import datetime

# Import our custom modules
from compact_camera import CompactCamera, SmartGlassesSim
from trajectory_prediction import TrajectoryPredictor

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class FairwayVisionApp:
    """
    Main application for the Fairway Vision smart glasses system.
    Integrates camera capture, ball detection, and trajectory prediction.

    Author: Shaily
    """
    
    def __init__(self, camera_index=0, debug=False, save_path="saved_shots"):
        # Initialize components
        self.debug = debug
        self.save_path = save_path
        
        # Create directory for saved shots if it doesn't exist
        # This helps organize output data from application runs.
        if not os.path.exists(save_path):
            try:
                os.makedirs(save_path)
                os.makedirs(os.path.join(save_path, "frames"))      # For saved raw/processed frames
                os.makedirs(os.path.join(save_path, "trajectory")) # For trajectory plots and heatmaps
                logger.info(f"Created save directory structure at {save_path}")
            except OSError as e:
                logger.error(f"Error creating save directories: {e}")
                # Decide if app should exit or continue without saving capability
        
        # Initialize the smart glasses hardware simulation or actual hardware interface
        # The SmartGlassesSim class from compact_camera.py handles camera feed and basic ball detection.
        self.glasses = SmartGlassesSim(camera_index=camera_index)
        
        # Initialize the trajectory predictor
        self.predictor = TrajectoryPredictor()
        
        # Application state
        self.is_running = False
        self.current_mode = "tracking"  # Modes: tracking, predicting, display
        self.tracking_active = False # True when ball is being actively tracked in current shot
        self.last_prediction = None # Stores the result of the last successful trajectory prediction
        self.prediction_timestamp = None # Timestamp of when the last_prediction was made
        
        # Shot history - stores data for multiple shots over an application session
        self.shots_history = []
        self.current_shot_data = None # Holds data for the shot currently being processed
        
        # Display settings
        self.display_mode = "camera"  # Options: camera, prediction, map
        self.overlay_info = True      # Show/hide informational text overlay
        self.highlight_ball = True    # Show/hide visual marker on detected ball
        
        # Visualization
        self.heatmap = None
        
        # Performance monitoring
        self.frame_times = deque(maxlen=30)
        self.fps = 0
        
        # User interface settings
        self.ui_color = (0, 255, 255)  # Yellow
        self.font = cv2.FONT_HERSHEY_SIMPLEX
        self.font_scale = 0.6
        self.help_visible = False
        
        logger.info("FairwayVision App initialized")
    
    def start(self):
        """Start the Fairway Vision application."""
        if self.glasses.start():
            self.is_running = True
            logger.info("FairwayVision App started successfully. Camera interface active.")
            return True
        else:
            logger.error("Failed to start FairwayVision App. Camera interface could not be initialized.")
            return False
    
    def stop(self):
        """Stop the Fairway Vision application."""
        self.is_running = False
        self.glasses.stop()
        logger.info("FairwayVision App stopped")
    
    def toggle_mode(self):
        """Toggle between different operation modes."""
        modes = ["tracking", "predicting", "display"]
        current_index = modes.index(self.current_mode)
        next_index = (current_index + 1) % len(modes)
        self.current_mode = modes[next_index]
        
        if self.current_mode == "tracking":
            self.predictor.reset() # Clear previous trajectory data
            self.current_shot_data = None # Reset current shot specific data
            self.tracking_active = False # Stop active tracking indications
        
        logger.info(f"Switched to {self.current_mode} mode")
        return self.current_mode
    
    def toggle_display(self):
        """Toggle between different display modes."""
        displays = ["camera", "prediction", "map"]
        current_index = displays.index(self.display_mode)
        next_index = (current_index + 1) % len(displays)
        self.display_mode = displays[next_index]
        logger.info(f"Switched to {self.display_mode} display")
        return self.display_mode
    
    def toggle_overlay(self):
        """Toggle visibility of information overlay."""
        self.overlay_info = not self.overlay_info
        return self.overlay_info
    
    def toggle_help(self):
        """Toggle visibility of help text."""
        self.help_visible = not self.help_visible
        return self.help_visible
    
    def process_frame(self):
        """Process a single frame from the camera."""
        start_time = time.time()
        
        # Get the latest frame from the camera interface
        frame, timestamp = self.glasses.camera.get_latest_frame()
        if frame is None:
            # logger.debug("No frame received from camera.") # Potentially too verbose for INFO
            return None
        
        # Make a copy for visualization to avoid modifying the original frame buffer
        display_frame = frame.copy()
        
        # Handle different operation modes
        if self.current_mode == "tracking":
            # Track the ball using the method from SmartGlassesSim (or actual hardware)
            detection = self.glasses.track_ball()
            
            if detection:
                # If a ball is detected, add its position to the predictor's history
                center = detection['center'] # (x,y) pixel coordinates
                self.predictor.add_position(center, timestamp)
                
                if not self.tracking_active and len(self.predictor.position_history) >= self.predictor.MIN_POSITIONS_FOR_PREDICTION:
                    # Sufficient initial points gathered to begin active tracking of this shot
                    self.tracking_active = True
                    logger.info("Ball tracking activated for current shot.")
                    
                    # Initialize data structure for the current shot
                    self.current_shot_data = {
                        "start_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                        "positions": [],
                        "prediction": None
                    }
                
                # Add to shot data if we're actively tracking
                if self.tracking_active and self.current_shot_data is not None:
                    self.current_shot_data["positions"].append({
                        "x": center[0],
                        "y": center[1],
                        "timestamp": timestamp,
                        "confidence": detection['confidence']
                    })
            
            # Draw detection visuals on the display frame
            if detection and self.highlight_ball:
                center = detection['center']
                radius = detection['radius'] # Estimated radius from detection
                # Draw circle around the detected ball
                cv2.circle(display_frame, center, radius, (0, 255, 0), 2) # Green circle
                cv2.circle(display_frame, center, 2, (0, 0, 255), -1)    # Red dot at center
                
                # Draw recent trajectory path (tail of observed points)
                # Uses position_history from the predictor which stores (position, timestamp)
                positions = [p[0] for p in self.predictor.position_history if p[0] is not None]
                for i in range(1, len(positions)):
                    cv2.line(display_frame, 
                            (int(positions[i-1][0]), int(positions[i-1][1])),
                            (int(positions[i][0]), int(positions[i][1])),
                            (255, 0, 0), 2) # Blue line for observed path
        
        elif self.current_mode == "predicting":
            # Attempt trajectory prediction if tracking was active and enough data exists
            if self.tracking_active and len(self.predictor.position_history) >= self.predictor.MIN_POSITIONS_FOR_PREDICTION:
                # Condition to avoid redundant predictions: 
                # Predict if: 
                #   1. No prediction has been made yet OR
                #   2. New position data has been added to current_shot_data since the last prediction.
                predict_now = False
                if self.last_prediction is None:
                    predict_now = True
                elif self.current_shot_data and self.current_shot_data["positions"]:
                    if self.prediction_timestamp is None or self.prediction_timestamp < self.current_shot_data["positions"][-1]["timestamp"]:
                        predict_now = True

                if predict_now:
                    logger.info("Attempting trajectory prediction...")
                    # Perform the prediction using TrajectoryPredictor
                    # TODO: Consider making wind parameters configurable via UI or external input
                    result = self.predictor.predict_trajectory(wind_speed=0.0, wind_direction=0.0)
                    
                    if result["status"] == "success":
                        self.last_prediction = result
                        self.prediction_timestamp = time.time() # Record time of this successful prediction
                        
                        # Update current_shot_data with the new prediction details
                        # Ensure all values are Python native types for JSON serialization
                        if self.current_shot_data is not None:
                            self.current_shot_data["prediction"] = {
                                "landing_position": [float(x) for x in result["landing_position"]],
                                "flight_time": float(result["flight_time"]),
                                "max_height": float(result["max_height"]),
                                "initial_velocity": float(result["initial_velocity"]),
                                "launch_angle_horizontal": float(result["launch_angle_horizontal"]),
                                "launch_angle_vertical": float(result["launch_angle_vertical"]),
                                "confidence": float(result["confidence"])
                            }
                        
                        # Generate heatmap for landing area visualization (not shown directly, but can be saved or used in map mode)
                        # Parameters like uncertainty, size, scale are currently hardcoded here.
                        self.heatmap = self.predictor.generate_landing_heatmap(
                            uncertainty=0.2, size=100, scale=1.0, # Example parameters
                            show_plot=False, save_path=None) # show_plot=False as it's for internal use here
                        
                        # Generate and save full trajectory visualization plots to files
                        self.save_trajectory_visualization()
                        
                        # Save all data for the current shot (including raw positions and prediction)
                        self.save_shot_data()
                        
                        logger.info(f"Trajectory predicted: {result['flight_time']:.2f}s flight, "
                                   f"landing at ({result['landing_position'][0]:.2f}, "
                                   f"{result['landing_position'][1]:.2f}) meters")
                    else:
                        logger.warning(f"Prediction failed: {result['message']}")
                
                # Draw a simplified directional cue for the predicted landing on the main display frame
                if self.last_prediction is not None:
                    # This is a very basic 2D directional cue on the screen.
                    # It does not project the 3D landing point onto the 2D camera view realistically.
                    landing_x_m = self.last_prediction["landing_position"][0] # X in meters from origin
                    landing_y_m = self.last_prediction["landing_position"][1] # Y in meters from origin
                    
                    # Calculate direction and distance in the 2D ground plane (meters)
                    # For display, this is simplified to a text arrow.
                    distance_m = np.sqrt(landing_x_m**2 + landing_y_m**2)
                    
                    # UI representation of the landing direction and distance
                    direction_text = f"Landing: ~{distance_m:.1f}m" # Simplified text
                    # Arrow symbols could be added based on angle of (landing_x_m, landing_y_m) relative to screen center
                    # e.g., if landing_x_m > 0, arrow points right "→", if < 0 points left "←"
                    # This part is highly conceptual for a real AR display.
                    text_size = cv2.getTextSize(direction_text, self.font, 1.0, 2)[0] # Smaller font for this
                    screen_center_x = display_frame.shape[1] // 2
                    text_x = screen_center_x - text_size[0] // 2
                    text_y = display_frame.shape[0] - 60 # Position towards bottom center
                    
                    # Draw with background
                    cv2.rectangle(display_frame, 
                                 (text_x - 10, text_y - text_size[1] - 10),
                                 (text_x + text_size[0] + 10, text_y + 10),
                                 (0, 0, 0), -1)
                    cv2.putText(display_frame, direction_text, 
                               (text_x, text_y), cv2.FONT_HERSHEY_SIMPLEX, 
                               1.0, (0, 255, 0), 2)
        
        elif self.current_mode == "display":
            # Display results mode
            if self.display_mode == "camera":
                # Just display the camera view
                pass
                
            elif self.display_mode == "prediction" and self.last_prediction is not None:
                # Create a schematic 2D side-view visualization of the predicted trajectory on an overlay
                height, width = display_frame.shape[:2]
                overlay = np.zeros((height, width, 3), dtype=np.uint8) # Black overlay
                
                # Draw a simple ground plane at the bottom of the overlay
                cv2.rectangle(overlay, (0, height-50), (width, height), (100, 100, 100), -1) # Gray ground
                
                if self.last_prediction and "trajectory" in self.last_prediction:
                    trajectory_points_m = self.last_prediction["trajectory"] # Array of (x,y,z) in meters
                    max_height_m = np.max(trajectory_points_m[:, 2]) if trajectory_points_m.size > 0 else 1.0
                    
                    # Horizontal distance for scaling: use the landing X-coordinate for simplicity in this 2D side view.
                    # A more accurate representation might use the total range along the primary direction of flight.
                    max_dist_m = self.last_prediction["landing_position"][0] if self.last_prediction["landing_position"][0] > 0 else 1.0
                    
                    # Define margins and drawable area for the plot
                    plot_margin_x = int(width * 0.1)
                    plot_margin_y_bottom = 50 # For ground plane
                    plot_margin_y_top = int(height * 0.1)
                    drawable_width = width - 2 * plot_margin_x
                    drawable_height = height - plot_margin_y_bottom - plot_margin_y_top

                    # Calculate scaling factors to fit trajectory into drawable area
                    scale_x = drawable_width / max_dist_m if max_dist_m > 0 else 1.0
                    scale_y = drawable_height / max_height_m if max_height_m > 0 else 1.0
                    
                    screen_points = []
                    for point_m in trajectory_points_m:
                        # For side view, use the first component of position (e.g., X or projected distance) for horizontal axis
                        # This assumes primary motion is along X in the model output for this simple plot.
                        dist_on_plot_axis_m = point_m[0] 
                        height_on_plot_axis_m = point_m[2]
                        
                        screen_x = plot_margin_x + int(dist_on_plot_axis_m * scale_x)
                        screen_y = (height - plot_margin_y_bottom) - int(height_on_plot_axis_m * scale_y)
                        screen_points.append((screen_x, screen_y))
                    
                    # Draw the scaled trajectory line
                    for i in range(1, len(screen_points)):
                        pt1 = screen_points[i-1]
                        pt2 = screen_points[i]
                        cv2.line(overlay, pt1, pt2, (0, 255, 255), 2)
                    
                    landing_dist_m = self.last_prediction["landing_position"][0]
                    landing_x_screen = plot_margin_x + int(landing_dist_m * scale_x)
                    landing_y_screen = height - plot_margin_y_bottom # On the ground plane
                    cv2.circle(overlay, (landing_x_screen, landing_y_screen), 5, (0, 0, 255), -1) # Red circle for landing
                    
                    # Add trajectory information text to the overlay
                    info_text = [
                        f"Range (X): {self.last_prediction['landing_position'][0]:.1f}m", # Assuming X is primary range direction
                        f"Max Height (Z): {self.last_prediction['max_height']:.1f}m",
                        f"Flight Time: {self.last_prediction['flight_time']:.1f}s",
                        f"Initial Speed: {self.last_prediction['initial_velocity']:.1f}m/s",
                        f"Confidence: {self.last_prediction['confidence']:.2f}"
                    ]
                    
                    for i, text in enumerate(info_text):
                        cv2.putText(overlay, text, (20, 40 + i * 30), 
                                   cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
                
                # Blend the overlay with the camera frame
                alpha = 0.7
                display_frame = cv2.addWeighted(display_frame, 1 - alpha, overlay, alpha, 0)
                
            elif self.display_mode == "map" and self.heatmap is not None:
                # Create a top-down map visualization of the landing area heatmap on an overlay
                height, width = display_frame.shape[:2]
                map_overlay = np.zeros((height, width, 3), dtype=np.uint8) # Black overlay
                
                # Define margins for the heatmap display area
                map_margin = 50 
                heatmap_display_width = width - 2 * map_margin
                heatmap_display_height = height - 2 * map_margin
                
                # Resize heatmap to fit the defined display area
                heatmap_resized = cv2.resize(self.heatmap, (heatmap_display_width, heatmap_display_height))
                
                # Convert normalized heatmap to a color map for visualization
                heatmap_color = cv2.applyColorMap((heatmap_resized * 255).astype(np.uint8), cv2.COLORMAP_JET)
                
                # Place heatmap onto the overlay
                y_offset = map_margin
                x_offset = map_margin
                map_overlay[y_offset:y_offset+heatmap_color.shape[0], 
                           x_offset:x_offset+heatmap_color.shape[1]] = heatmap_color
                
                # Add title for the map view
                cv2.putText(map_overlay, "Predicted Landing Area (Top-Down)", 
                           (width//2 - 200, 30), self.font, 0.8, (255, 255, 255), 2)
                
                # Add a conceptual distance scale (assuming heatmap scale corresponds to this)
                # This scale is illustrative; real accuracy depends on heatmap 'scale' parameter.
                cv2.line(map_overlay, (map_margin, height-30), (map_margin + 100, height-30), (255, 255, 255), 2) # 100 pixels line
                cv2.putText(map_overlay, "~10m Scale", (map_margin, height-40), 
                           self.font, 0.6, (255, 255, 255), 2)
                
                # Blend the map overlay with the camera frame
                alpha = 0.85
                display_frame = cv2.addWeighted(display_frame, 1 - alpha, map_overlay, alpha, 0)
        
        # Add information overlay if enabled
        if self.overlay_info:
            self.add_info_overlay(display_frame)
        
        # Add help text if enabled
        if self.help_visible:
            self.add_help_overlay(display_frame)
        
        # Calculate frame processing time and FPS
        processing_time = time.time() - start_time
        self.frame_times.append(processing_time)
        self.fps = 1.0 / np.mean(self.frame_times) if self.frame_times else 0
        
        return display_frame
    
    def add_info_overlay(self, frame):
        """Add information overlay to the display frame."""
        # Get system status
        status = self.glasses.get_status()
        
        # Background for the overlay
        cv2.rectangle(frame, (10, 10), (300, 140), (0, 0, 0), -1)
        cv2.rectangle(frame, (10, 10), (300, 140), self.ui_color, 1)
        
        # Add status information
        cv2.putText(frame, f"Mode: {self.current_mode.capitalize()}", 
                   (20, 35), self.font, self.font_scale, self.ui_color, 1)
        
        cv2.putText(frame, f"Display: {self.display_mode.capitalize()}", 
                   (20, 60), self.font, self.font_scale, self.ui_color, 1)
        
        cv2.putText(frame, f"FPS: {self.fps:.1f}", 
                   (20, 85), self.font, self.font_scale, self.ui_color, 1)
        
        tracking_status = "Active" if self.tracking_active else "Inactive"
        cv2.putText(frame, f"Tracking: {tracking_status}", 
                   (20, 110), self.font, self.font_scale, self.ui_color, 1)
        
        confidence = self.glasses.camera.detection_confidence
        cv2.putText(frame, f"Confidence: {confidence:.2f}", 
                   (20, 135), self.font, self.font_scale, self.ui_color, 1)
        
        # Add contextual guidance text at the bottom of the screen
        guidance_text_y = frame.shape[0] - 30
        guidance_text_x_offset = 200 # Approximate offset for centering

        if self.current_mode == "tracking":
            msg = "Looking for golf ball..."
            if self.tracking_active:
                msg = "Golf ball detected! Tracking active."
            cv2.putText(frame, msg, (frame.shape[1]//2 - guidance_text_x_offset, guidance_text_y), 
                       self.font, self.font_scale, (0, 255, 0), 1)
        
        elif self.current_mode == "predicting":
            if self.last_prediction is None:
                msg = "Insufficient data for prediction. Continue tracking."
            else:
                msg = "Trajectory predicted. Press 'D' for detailed views."
            cv2.putText(frame, msg, (frame.shape[1]//2 - guidance_text_x_offset, guidance_text_y), 
                       self.font, self.font_scale, (0, 255, 0), 1)
        
        # Add "Press H for help" reminder at top-right
        # Text position is relative to frame width.
        cv2.putText(frame, "Press 'H' for help", 
                   (frame.shape[1] - 180, 30), self.font, 0.5, (200, 200, 200), 1)
    
    def add_help_overlay(self, frame):
        """Add help text overlay to the display frame."""
        # Create semi-transparent overlay
        overlay = frame.copy()
        cv2.rectangle(overlay, (0, 0), (frame.shape[1], frame.shape[0]), (0, 0, 0), -1)
        
        # Help text content and layout
        # Consider making this configurable or loading from a file if it grows larger.
        help_text = [
            "Fairway Vision Help",
            "",
            "M: Toggle Mode (tracking/predicting/display)",
            "D: Toggle Display (camera/prediction/map)",
            "O: Toggle Information Overlay",
            "S: Save Current Frame",
            "R: Reset Tracking",
            "H: Toggle Help",
            "Q: Quit Application",
            "",
            "Press any key to close this help"
        ]
        
        # Add text
        y_offset = frame.shape[0] // 2 - len(help_text) * 15
        for i, line in enumerate(help_text):
            cv2.putText(overlay, line, (frame.shape[1]//2 - 150, y_offset + i * 30), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
        
        # Blend with original frame to make help text readable over camera feed
        alpha = 0.85 # Transparency factor for the help overlay
        frame[:] = cv2.addWeighted(frame, 1 - alpha, overlay, alpha, 0)
    
    def save_frame(self):
        """Save the current display frame (including overlays) to a file."""
        # Process the frame to include all current visualizations and overlays first
        # This ensures what is saved is what the user would be seeing (approximately).
        processed_display_frame = self.process_frame() 
        # Note: process_frame reads a new frame. If a specific older frame is needed, 
        # it should be passed or handled differently.
        # For saving the *exact* frame that was last shown, a copy should be stored before new processing.
        # However, for simplicity, we re-process to get the latest state with overlays.

        if processed_display_frame is None:
            logger.warning("No processed frame available to save (camera might be disconnected).")
            return None

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f") # Added microseconds for uniqueness
        filename = os.path.join(self.save_path, "frames", f"frame_{timestamp}.jpg")
        
        # Save the frame
        try:
            cv2.imwrite(filename, processed_display_frame)
            logger.info(f"Frame saved to {filename}")
            return filename
        except Exception as e:
            logger.error(f"Error saving frame to {filename}: {e}")
            return None
    
    def save_trajectory_visualization(self):
        """Save visualizations (trajectory plot, heatmap) of the last prediction to files."""
        if self.last_prediction is None:
            logger.warning("No prediction available to save visualization.")
            return None
        
        # Create a unique timestamp for this set of visualization files
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f") # Added microseconds
        
        # Save the trajectory visualization using the method from TrajectoryPredictor
        trajectory_file = os.path.join(self.save_path, "trajectory", f"trajectory_plot_{timestamp}.png")
        self.predictor.visualize_trajectory(show_plot=False, save_path=trajectory_file)
        
        # Save the landing heatmap visualization using the method from TrajectoryPredictor
        heatmap_file = os.path.join(self.save_path, "trajectory", f"landing_heatmap_{timestamp}.png")
        self.predictor.generate_landing_heatmap(
            uncertainty=0.2, size=100, scale=1.0, 
            show_plot=False, save_path=heatmap_file)
        
        logger.info(f"Trajectory visualizations saved: {trajectory_file} and {heatmap_file}")
        return trajectory_file
    
    def save_shot_data(self):
        """Save the current shot data to the shots history."""
        if self.current_shot_data is None or self.last_prediction is None:
            return
        
        # Create a copy of the current shot data
        shot_data = self.current_shot_data.copy()
        
        # Add end timestamp
        shot_data["end_time"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        # Add to shots history
        self.shots_history.append(shot_data)
        
        # Save to JSON file
        shots_file = os.path.join(self.save_path, "shots_history.json")
        
        try:
            # Read existing data if file exists
            existing_data = []
            if os.path.exists(shots_file):
                with open(shots_file, 'r') as f:
                    existing_data = json.load(f)
            
            # Append new shot
            existing_data.append(shot_data)
            
            # Write back to file
            with open(shots_file, 'w') as f:
                json.dump(existing_data, f, indent=2)
            
            logger.info(f"Shot data saved to {shots_file}")
        except Exception as e:
            logger.error(f"Error saving shot data to JSON file {shots_file}: {str(e)}")
    
    def reset_tracking(self):
        """Reset all tracking and prediction states for a new shot attempt."""
        self.predictor.reset()
        self.glasses.ball_positions.clear()
        self.current_shot_data = None
        self.tracking_active = False
        self.last_prediction = None
        self.prediction_timestamp = None
        self.heatmap = None
        logger.info("Tracking reset")


def main():
    # Parse command line arguments
    parser = argparse.ArgumentParser(description="Fairway Vision Smart Glasses Application - Golf Ball Tracker")
    parser.add_argument("--camera", type=int, default=0, help="Camera index (e.g., 0, 1) or path to video file.")
    parser.add_argument("--debug", action="store_true", help="Enable detailed debug logging and visualizations.")
    parser.add_argument("--save-path", default="saved_shots", help="Directory path to save captured frames, trajectory data, and shot history.")
    args = parser.parse_args()
    
    # Configure logger level based on debug flag
    if args.debug:
        logger.setLevel(logging.DEBUG)
        logger.debug("Debug mode enabled.")
    else:
        logger.setLevel(logging.INFO)
    
    # Initialize and start the app
    app = FairwayVisionApp(
        camera_index=args.camera,
        debug=args.debug,
        save_path=args.save_path
    )
    
    if app.start():
        try:
            # Main application loop
            while app.is_running:
                # Process the current frame
                frame = app.process_frame()
                
                if frame is not None:
                    # Display the frame
                    cv2.imshow("Fairway Vision", frame)
                    
                    # Process key presses
                    key = cv2.waitKey(1) & 0xFF
                    
                    if key == ord('q'):
                        # Quit the application
                        logger.info("'q' pressed, shutting down.")
                        break
                    elif key == ord('m'):
                        # Toggle mode
                        app.toggle_mode()
                    elif key == ord('d'):
                        # Toggle display mode
                        app.toggle_display()
                    elif key == ord('o'):
                        # Toggle overlay
                        app.toggle_overlay()
                    elif key == ord('s'):
                        # Save current frame
                        app.save_frame()
                    elif key == ord('r'):
                        # Reset tracking
                        app.reset_tracking()
                    elif key == ord('h'):
                        # Toggle help display
                        app.toggle_help()
                    # Add any other keybinds for new features here
                
                # Small sleep to yield CPU, adjust as needed for responsiveness vs. resource use.
                # For a real-time application, this might be managed by camera frame rate or a dedicated timer.
                time.sleep(0.01) # 10ms sleep
                
        except KeyboardInterrupt:
            logger.info("Application interrupted by user")
        finally:
            # Clean up
            app.stop()
            cv2.destroyAllWindows()
            logger.info("Application terminated cleanly.")
    else:
        logger.error("Failed to start the FairwayVision application. Check camera and dependencies.")


if __name__ == "__main__":
    main() 