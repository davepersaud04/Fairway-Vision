import numpy as np
import cv2
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from scipy.optimize import curve_fit
import time
import math
from matplotlib.lines import Line2D

class TrajectoryPredictor:
    """
    Predicts the full trajectory of a golf ball based on the initial flight path captured by camera.
    Accounts for physics including gravity, drag, and optionally wind and Magnus effects (Magnus is conceptual here).

    Author: Shaily
    """
    
    def __init__(self):
        # Physics constants - Standard atmospheric and golf ball parameters
        self.GRAVITY = 9.81  # m/s², acceleration due to gravity
        self.AIR_DENSITY = 1.225  # kg/m³, typical air density at sea level, 15°C
        self.BALL_MASS = 0.0459  # kg (standard golf ball mass, ~1.62 ounces)
        self.BALL_RADIUS = 0.0213  # m (standard golf ball radius, ~0.84 inches)
        self.BALL_CROSS_SECTION = np.pi * self.BALL_RADIUS**2 # m², frontal area of the ball
        self.DRAG_COEFFICIENT = 0.4  # Dimensionless, typical value for a dimpled golf ball. Can vary with Reynolds number/speed.
        # NOTE: Magnus effect / lift coefficient for spin is not explicitly modeled here but would be an important addition for higher accuracy.
        
        # Calibration parameters - CRITICAL for real-world accuracy
        # This factor converts pixel coordinates from the camera to real-world meters.
        # It depends heavily on camera intrinsics, lens, and distance to the object if not using stereo vision.
        # REQUIRES CAREFUL CALIBRATION for any deployment.
        self.PIXELS_TO_METERS = 0.01  # Example: 1 pixel = 0.01 meters at a certain reference depth.
        
        # Assumed time interval between frames from the camera.
        # Should match the actual camera's FPS (Frames Per Second).
        self.FRAME_TIME_DELTA = 1/30  # Assuming 30 FPS camera
        
        # Tracking parameters
        self.position_history = [] # Stores tuples of (position, timestamp)
        self.velocity_history = [] # Stores tuples of ((vx,vy,vz), timestamp)
        self.MIN_POSITIONS_FOR_PREDICTION = 5  # Minimum number of observed points to attempt a trajectory prediction
        
        # Prediction results
        self.predicted_trajectory = None
        self.landing_position = None
        self.flight_time = None
        self.max_height = None
        self.confidence_score = None
        
    def add_position(self, position, timestamp=None):
        """
        Add a detected ball position to the history.
        Position should be in (x,y,z) format, where z can be 0 if not available.
        """
        if timestamp is None:
            timestamp = time.time()
            
        self.position_history.append((position, timestamp))
        
        # Calculate velocity if we have at least 2 positions
        if len(self.position_history) >= 2:
            prev_pos, prev_time = self.position_history[-2]
            curr_pos, curr_time = self.position_history[-1]
            
            # Calculate velocity components
            dt = curr_time - prev_time
            if dt > 0:
                vx = (curr_pos[0] - prev_pos[0]) / dt
                vy = (curr_pos[1] - prev_pos[1]) / dt
                vz = 0  # Default if we don't have z coordinate
                
                if len(curr_pos) > 2 and len(prev_pos) > 2:
                    vz = (curr_pos[2] - prev_pos[2]) / dt
                
                self.velocity_history.append(((vx, vy, vz), curr_time))
    
    def reset(self):
        """Reset the tracker for a new shot."""
        self.position_history = []
        self.velocity_history = []
        self.predicted_trajectory = None
        self.landing_position = None
        self.flight_time = None
        self.max_height = None
        self.confidence_score = None
    
    def estimate_initial_conditions(self):
        """
        Estimate the initial velocity and launch angle based on the observed trajectory.
        Returns: (initial_velocity, launch_angle_x, launch_angle_y) in m/s and radians
        """
        if len(self.position_history) < self.MIN_POSITIONS_FOR_PREDICTION:
            return None, None, None
        
        # Convert positions to numpy array for easier manipulation
        positions = np.array([p[0] for p in self.position_history])
        
        # If we only have 2D positions, add a zero z-coordinate
        if positions.shape[1] == 2:
            positions = np.column_stack((positions, np.zeros(len(positions))))
        
        # Convert pixels to meters
        positions_meters = positions * self.PIXELS_TO_METERS
        
        # Calculate time deltas
        times = np.array([p[1] for p in self.position_history])
        times = times - times[0]  # Start at t=0
        
        # Fit a quadratic function to the y-coordinates to account for gravity
        # y(t) = y₀ + v₀y*t - 0.5*g*t²
        def y_trajectory(t, y0, v0y):
            return y0 + v0y * t - 0.5 * self.GRAVITY * t**2
        
        # Fit a linear function to the x-coordinates (assuming x is horizontal and less affected by gravity initially)
        # x(t) = x₀ + v₀x*t
        def x_trajectory(t, x0, v0x):
            return x0 + v0x * t
        
        try:
            # Fit the functions to our observed data
            y_params, _ = curve_fit(y_trajectory, times, positions_meters[:, 1])
            x_params, _ = curve_fit(x_trajectory, times, positions_meters[:, 0])
            
            # Extract initial position and velocity components
            x0, v0x = x_params
            y0, v0y = y_params # y0 is initial y-position, v0y is initial y-velocity
            
            # Calculate initial velocity magnitude and launch angles
            initial_velocity_magnitude = np.sqrt(v0x**2 + v0y**2) # This is speed in the camera's XY plane
            launch_angle_horizontal_rad = np.arctan2(v0y, v0x)  # Angle in the camera's XY plane (rad)
            
            # IMPORTANT: Vertical launch angle (out of the camera's XY plane) estimation is highly limited with a single camera.
            # A value of 0 is used here, implying the initial velocity is primarily in the camera's XY plane.
            # This is a major simplification. True 3D trajectory prediction requires accurate VLA, typically from stereo vision or other sensors.
            launch_angle_vertical_rad = 0  
            
            return initial_velocity_magnitude, launch_angle_horizontal_rad, launch_angle_vertical_rad
            
        except (ValueError, RuntimeError) as e:
            print(f"Error during trajectory fitting: {e}")
            return None, None, None
    
    def predict_trajectory(self, wind_speed=0, wind_direction=0, points=100):
        """
        Predict the full trajectory of the golf ball.
        
        Args:
            wind_speed: Wind speed in m/s.
            wind_direction: Wind direction in radians. Convention: 0 is along positive X-axis (e.g., East),
                            π/2 is along positive Y-axis (e.g., North). Meteorological conventions may differ (e.g., 0 for North).
            points: Number of points to generate in the trajectory.
            
        Returns:
            Dictionary with predicted trajectory information
        """
        # Check if we have enough data
        if len(self.position_history) < self.MIN_POSITIONS_FOR_PREDICTION:
            return {
                "status": "insufficient_data",
                "message": f"Need at least {self.MIN_POSITIONS_FOR_PREDICTION} positions to predict trajectory"
            }
        
        # Estimate initial conditions
        initial_velocity, launch_angle_h, launch_angle_v = self.estimate_initial_conditions()
        
        if initial_velocity is None:
            return {
                "status": "estimation_failed",
                "message": "Failed to estimate initial conditions"
            }
        
        # Calculate initial velocity components
        v0x = initial_velocity * np.cos(launch_angle_h) * np.cos(launch_angle_v)
        v0y = initial_velocity * np.sin(launch_angle_h) * np.cos(launch_angle_v)
        v0z = initial_velocity * np.sin(launch_angle_v)
        
        # Extract the initial position
        x0, y0, z0 = self.position_history[0][0]
        x0 *= self.PIXELS_TO_METERS
        y0 *= self.PIXELS_TO_METERS
        z0 *= self.PIXELS_TO_METERS
        
        # Simulate the trajectory with physics
        dt = 0.01  # time step for simulation
        max_time = 10  # maximum time to simulate (10 seconds)
        
        # Arrays to store the trajectory
        times = np.linspace(0, max_time, points)
        trajectory = np.zeros((points, 3))
        
        # Initial conditions
        trajectory[0] = [x0, y0, z0]
        vx, vy, vz = v0x, v0y, v0z
        
        # Wind components
        wind_x = wind_speed * np.cos(wind_direction)
        wind_y = wind_speed * np.sin(wind_direction)
        wind_z = 0  # Assuming horizontal wind
        
        max_height = z0
        landing_index = -1
        
        # Simulate the flight
        for i in range(1, points):
            # Time step
            t = times[i] - times[i-1]
            
            # Calculate drag force
            v_rel_x = vx - wind_x
            v_rel_y = vy - wind_y
            v_rel_z = vz - wind_z
            v_rel_mag = np.sqrt(v_rel_x**2 + v_rel_y**2 + v_rel_z**2)
            
            # Drag force magnitude
            drag_force = 0.5 * self.AIR_DENSITY * self.DRAG_COEFFICIENT * self.BALL_CROSS_SECTION * v_rel_mag**2
            
            # Drag acceleration components
            drag_ax = -drag_force * v_rel_x / (v_rel_mag * self.BALL_MASS) if v_rel_mag > 0 else 0
            drag_ay = -drag_force * v_rel_y / (v_rel_mag * self.BALL_MASS) if v_rel_mag > 0 else 0
            drag_az = -drag_force * v_rel_z / (v_rel_mag * self.BALL_MASS) if v_rel_mag > 0 else 0
            
            # Update velocity with gravity and drag
            vx += drag_ax * t
            vy += drag_ay * t
            vz += (drag_az - self.GRAVITY) * t  # z is up, gravity pulls down
            
            # Update position
            trajectory[i, 0] = trajectory[i-1, 0] + vx * t
            trajectory[i, 1] = trajectory[i-1, 1] + vy * t
            trajectory[i, 2] = trajectory[i-1, 2] + vz * t
            
            # Keep track of max height
            if trajectory[i, 2] > max_height:
                max_height = trajectory[i, 2]
            
            # Check if the ball has hit the ground
            if i > 0 and trajectory[i, 2] <= 0 and trajectory[i-1, 2] > 0:
                landing_index = i
                # Interpolate to find exact landing point
                ratio = trajectory[i-1, 2] / (trajectory[i-1, 2] - trajectory[i, 2])
                landing_x = trajectory[i-1, 0] + ratio * (trajectory[i, 0] - trajectory[i-1, 0])
                landing_y = trajectory[i-1, 1] + ratio * (trajectory[i, 1] - trajectory[i-1, 1])
                break
        
        # Find the landing position and time
        if landing_index > 0:
            landing_position = (trajectory[landing_index, 0], trajectory[landing_index, 1], 0)
            flight_time = times[landing_index]
            # Trim the trajectory to the landing point
            trajectory = trajectory[:landing_index+1]
            times = times[:landing_index+1]
        else:
            # If the ball doesn't land within the simulation time, use the last point
            landing_position = (trajectory[-1, 0], trajectory[-1, 1], trajectory[-1, 2])
            flight_time = times[-1]
        
        # Calculate confidence score (heuristic based on number of observed points).
        # This is a simple placeholder and should ideally be replaced with a more statistically robust metric.
        # For example, considering the goodness-of-fit from curve_fit or variance in observations.
        confidence_score = min(0.95, len(self.position_history) / 20.0) # Ensure float division
        
        # Store the results
        self.predicted_trajectory = trajectory
        self.landing_position = landing_position
        self.flight_time = flight_time
        self.max_height = max_height
        self.confidence_score = confidence_score
        
        return {
            "status": "success",
            "trajectory": trajectory,
            "landing_position": landing_position,
            "flight_time": flight_time,
            "max_height": max_height,
            "initial_velocity": initial_velocity,
            "launch_angle_horizontal": np.degrees(launch_angle_h),
            "launch_angle_vertical": np.degrees(launch_angle_v),
            "confidence": confidence_score
        }
    
    def visualize_trajectory(self, show_plot=True, save_path=None):
        """
        Visualize the predicted trajectory in 3D.
        """
        if self.predicted_trajectory is None:
            print("No trajectory to visualize. Run predict_trajectory first.")
            return
        
        # Create 3D plot
        fig = plt.figure(figsize=(10, 8))
        ax = fig.add_subplot(111, projection='3d')
        
        # Plot the observed positions
        observed_positions = np.array([p[0] for p in self.position_history]) * self.PIXELS_TO_METERS
        if observed_positions.shape[1] == 2:
            observed_positions = np.column_stack((observed_positions, np.zeros(len(observed_positions))))
            
        ax.scatter(observed_positions[:, 0], observed_positions[:, 1], observed_positions[:, 2], 
                   color='blue', s=50, label='Observed Positions')
        
        # Plot the predicted trajectory
        ax.plot(self.predicted_trajectory[:, 0], self.predicted_trajectory[:, 1], self.predicted_trajectory[:, 2], 
                color='red', linestyle='-', linewidth=2, label='Predicted Trajectory')
        
        # Plot the landing position
        ax.scatter([self.landing_position[0]], [self.landing_position[1]], [self.landing_position[2]], 
                   color='green', s=100, marker='x', label='Predicted Landing')
        
        # Add a ground plane
        max_range = max(np.max(self.predicted_trajectory[:, 0]), np.max(self.predicted_trajectory[:, 1]))
        min_range = min(np.min(self.predicted_trajectory[:, 0]), np.min(self.predicted_trajectory[:, 1]))
        range_padding = (max_range - min_range) * 0.2
        x_ground = np.linspace(min_range - range_padding, max_range + range_padding, 10)
        y_ground = np.linspace(min_range - range_padding, max_range + range_padding, 10)
        X_ground, Y_ground = np.meshgrid(x_ground, y_ground)
        Z_ground = np.zeros_like(X_ground)
        ax.plot_surface(X_ground, Y_ground, Z_ground, alpha=0.2, color='gray')
        
        # Add labels and title
        ax.set_xlabel('X Distance (m)')
        ax.set_ylabel('Y Distance (m)')
        ax.set_zlabel('Height (m)')
        ax.set_title('Golf Ball Trajectory Prediction')
        
        # Add flight statistics as text
        stats_text = (
            f"Flight Time: {self.flight_time:.2f} s\n"
            f"Max Height: {self.max_height:.2f} m\n"
            f"Distance: {np.sqrt(self.landing_position[0]**2 + self.landing_position[1]**2):.2f} m\n"
            f"Confidence: {self.confidence_score:.2f}"
        )
        plt.figtext(0.02, 0.02, stats_text, fontsize=9)
        
        # Add legend
        ax.legend()
        
        # Use equal aspect ratio
        max_range = max(np.max(self.predicted_trajectory[:, 0]) - np.min(self.predicted_trajectory[:, 0]),
                         np.max(self.predicted_trajectory[:, 1]) - np.min(self.predicted_trajectory[:, 1]),
                         np.max(self.predicted_trajectory[:, 2]))
        mid_x = (np.max(self.predicted_trajectory[:, 0]) + np.min(self.predicted_trajectory[:, 0])) / 2
        mid_y = (np.max(self.predicted_trajectory[:, 1]) + np.min(self.predicted_trajectory[:, 1])) / 2
        mid_z = (np.max(self.predicted_trajectory[:, 2]) + np.min(self.predicted_trajectory[:, 2])) / 2
        ax.set_xlim(mid_x - max_range/2, mid_x + max_range/2)
        ax.set_ylim(mid_y - max_range/2, mid_y + max_range/2)
        ax.set_zlim(0, mid_z + max_range/2)
        
        # Save or show the plot
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
            print(f"Trajectory visualization saved to {save_path}")
        
        if show_plot:
            plt.show()
        else:
            plt.close()

    def generate_landing_heatmap(self, uncertainty=0.1, size=100, scale=1.0, show_plot=True, save_path=None):
        """
        Generate a heatmap of the likely landing area considering uncertainty.
        
        Args:
            uncertainty: Standard deviation in prediction (0-1)
            size: Size of the heatmap grid
            scale: Scale factor for visualization (meters per grid cell)
            show_plot: Whether to display the plot
            save_path: Optional path to save the plot
            
        Returns:
            The heatmap as a numpy array
        """
        if self.landing_position is None:
            print("No landing position predicted. Run predict_trajectory first.")
            return None
        
        # Create a grid centered on the landing position
        landing_x, landing_y, _ = self.landing_position
        grid_half_size = size // 2
        
        x = np.linspace(landing_x - grid_half_size * scale, landing_x + grid_half_size * scale, size)
        y = np.linspace(landing_y - grid_half_size * scale, landing_y + grid_half_size * scale, size)
        X, Y = np.meshgrid(x, y)
        
        # Calculate distance from landing position for each grid point
        distances = np.sqrt((X - landing_x)**2 + (Y - landing_y)**2)
        
        # Convert distances to probabilities using Gaussian distribution
        sigma = uncertainty * np.sqrt(landing_x**2 + landing_y**2)  # Scale uncertainty with distance
        probabilities = np.exp(-distances**2 / (2 * sigma**2))
        
        # Normalize the probabilities
        probabilities = probabilities / np.max(probabilities)
        
        # Plot the heatmap
        if show_plot or save_path:
            plt.figure(figsize=(10, 8))
            
            # Plot the heatmap
            plt.imshow(probabilities, extent=[x[0], x[-1], y[0], y[-1]], 
                      origin='lower', cmap='hot', interpolation='bilinear')
            
            # Add the landing position marker
            plt.scatter([landing_x], [landing_y], color='white', s=100, marker='x')
            
            # Add a colorbar
            cbar = plt.colorbar(label='Landing Probability')
            
            # Add labels and title
            plt.xlabel('X Distance (m)')
            plt.ylabel('Y Distance (m)')
            plt.title('Predicted Landing Area')
            
            # Add a contour showing 50% and 90% confidence regions
            plt.contour(X, Y, probabilities, levels=[0.5, 0.9], colors=['white', 'cyan'], 
                       linestyles=['--', '-'], linewidths=[1, 2])
            
            # Add legend for contour lines
            legend_elements = [
                Line2D([0], [0], color='white', linestyle='--', lw=1, label='50% Confidence'),
                Line2D([0], [0], color='cyan', linestyle='-', lw=2, label='90% Confidence')
            ]
            plt.legend(handles=legend_elements, loc='upper right')
            
            # Add confidence text
            plt.figtext(0.02, 0.02, f"Prediction Confidence: {self.confidence_score:.2f}", fontsize=9)
            
            if save_path:
                plt.savefig(save_path, dpi=300, bbox_inches='tight')
                print(f"Landing heatmap saved to {save_path}")
            
            if show_plot:
                plt.show()
            else:
                plt.close()
        
        return probabilities

    @staticmethod
    def convert_2d_to_3d(positions_2d, camera_matrix, distance_estimate):
        """
        Convert 2D camera positions to 3D world coordinates using an estimated distance.
        This is a simplification - true 3D would require multiple cameras or depth sensing.
        
        Args:
            positions_2d: List of (x,y) positions in camera pixel coordinates.
            camera_matrix: 3x3 camera intrinsic matrix [ [fx, 0, cx], [0, fy, cy], [0, 0, 1] ].
            distance_estimate: Estimated distance (depth) from the camera to the ball along the Z-axis (camera's optical axis).
            
        Returns:
            List of (X,Y,Z) positions in world coordinates (relative to camera if camera is origin).
            Note: The Z coordinate here is the assumed depth (distance_estimate).
            X and Y are calculated based on this assumed depth.
        """
        positions_3d = []
        if camera_matrix is None or not hasattr(camera_matrix, "shape") or camera_matrix.shape != (3,3):
            print("Warning: Valid camera_matrix (3x3) is required for 2D to 3D conversion. Skipping.")
            return positions_2d # Or raise error, or return empty
            
        fx = camera_matrix[0, 0]
        fy = camera_matrix[1, 1]
        cx = camera_matrix[0, 2]
        cy = camera_matrix[1, 2]

        for x_pixel, y_pixel in positions_2d:
            # Undistort points first if distortion coefficients are available (not shown here)
            
            # Convert pixel coordinates to normalized image coordinates
            x_normalized = (x_pixel - cx) / fx
            y_normalized = (y_pixel - cy) / fy
            
            # Calculate 3D coordinates in camera coordinate system
            # Assumes the Z coordinate (depth) is the provided distance_estimate
            X_cam = x_normalized * distance_estimate
            Y_cam = y_normalized * distance_estimate
            Z_cam = distance_estimate # This is the assumed depth
            
            # If a transformation from camera to world coordinates is known, apply it here.
            # For simplicity, assuming camera coordinates are used or are equivalent to world for this estimate.
            positions_3d.append((X_cam, Y_cam, Z_cam))
        
        return positions_3d


def simulate_ball_detection(frames=15, noise_level=2.0):
    """
    Simulate ball detection from a camera for testing the predictor.
    """
    # Define the initial conditions
    initial_velocity = 50.0  # m/s
    launch_angle = np.radians(15)  # degrees to radians
    
    # Define the camera parameters
    fps = 30
    dt = 1.0 / fps # Time step between frames
    
    # Create the trajectory (simple projectile motion without drag for this simulation)
    g = 9.81  # m/s^2, gravity
    
    positions = []
    print("Simulating detected positions (pixels):")
    for i in range(frames):
        t = i * dt # Time at current frame
        
        # True physical position (meters)
        x_m = initial_velocity * np.cos(launch_angle) * t
        y_m = initial_velocity * np.sin(launch_angle) * t - 0.5 * g * t**2
        
        # Simulate conversion to pixel coordinates for camera view
        # Example: 10 pixels per meter scaling, and an offset to position in frame.
        # y_pixel is inverted as image y-coordinates typically start from top-left.
        x_pixel = x_m * 10 + 100  # Scale: 10px/m, Offset X: 100px
        y_pixel = 500 - (y_m * 10)  # Scale: 10px/m, Offset Y: 500px (from top)
        
        # Add some random noise to simulate detection inaccuracies
        noise_x = np.random.normal(0, noise_level)
        noise_y = np.random.normal(0, noise_level)
        x_pixel_noisy = x_pixel + noise_x
        y_pixel_noisy = y_pixel + noise_y
        
        positions.append((x_pixel_noisy, y_pixel_noisy))
        # print(f"  t={t:.2f}s: (Xm={x_m:.2f}, Ym={y_m:.2f}) -> (Xp={x_pixel_noisy:.2f}, Yp={y_pixel_noisy:.2f})")
    
    return positions


if __name__ == "__main__":
    # Test the predictor with simulated data
    print("Testing TrajectoryPredictor with simulated data...")
    
    # Create a predictor
    predictor = TrajectoryPredictor()
    
    # Simulate ball detection
    positions = simulate_ball_detection(frames=15, noise_level=2.0)
    
    # Add the positions to the predictor
    current_time = time.time()
    for i, pos in enumerate(positions):
        timestamp = current_time + i * 1/30  # 30fps
        predictor.add_position(pos, timestamp)
    
    # Predict the trajectory
    result = predictor.predict_trajectory(wind_speed=2.0, wind_direction=np.radians(45))
    
    # Print the prediction result
    if result["status"] == "success":
        print(f"Prediction successful:")
        print(f"  Initial velocity: {result['initial_velocity']:.2f} m/s")
        print(f"  Launch angle (horizontal): {result['launch_angle_horizontal']:.2f} degrees")
        print(f"  Launch angle (vertical): {result['launch_angle_vertical']:.2f} degrees")
        print(f"  Flight time: {result['flight_time']:.2f} seconds")
        print(f"  Max height: {result['max_height']:.2f} meters")
        print(f"  Landing position: ({result['landing_position'][0]:.2f}, {result['landing_position'][1]:.2f}, {result['landing_position'][2]:.2f}) meters")
        print(f"  Confidence: {result['confidence']:.2f}")
        
        # Visualize the trajectory
        predictor.visualize_trajectory(show_plot=True, save_path="trajectory_prediction.png")
        
        # Generate a landing heatmap
        predictor.generate_landing_heatmap(uncertainty=0.2, size=100, scale=1.0, 
                                          show_plot=True, save_path="landing_heatmap.png")
    else:
        print(f"Prediction failed: {result['message']}")
        predictor.reset() # Reset predictor state after a failed attempt 