"""
Proof-of-Concept (PoC) Script for Golf Ball Tracking with Auto HSV Calibration.

Author: Shaily

Purpose:
This script was developed to experiment with and test automatic and manual HSV color
threshold calibration for detecting golf balls of various colors (white, yellow, orange)
under different lighting conditions. It includes:
- Manual HSV trackbar adjustments.
- An experimental automatic calibration mode that analyzes frame lighting and
  adaptively adjusts HSV thresholds.
- Camera selection utility.
- Basic ball detection, tracking (trail), and speed estimation.
- Debug frame saving capability.

Status:
This is an EXPERIMENTAL script and is NOT the main production application.
It serves as a valuable tool for understanding HSV calibration challenges and for
generating test data or initial HSV values.

Key Components for Understanding:
- `analyze_lighting()`: Estimates overall frame brightness.
- `adjust_hsv_for_lighting()`: Suggests HSV adjustments based on lighting and ball color (heuristic).
- `adaptive_search()`: Attempts to find the ball by expanding/contracting HSV ranges (heuristic).
- Main loop: Orchestrates frame processing, auto/manual mode switching, detection, and display.

Notes for New Developers:
- Many parameters (e.g., MIN_BALL_AREA, HSV adjustment steps, specific HSV ranges
  in `adjust_hsv_for_lighting`) are heuristic and were likely tuned empirically.
- The `pixels_per_meter` value is critical for accurate speed estimation and has a TODO for calibration.
- This script uses the `imutils` library (ensure it's in requirements.txt if using).
- The auto-calibration logic is a stateful process; review its flow carefully if modifying.
"""
import cv2
import numpy as np
import imutils
import time
import argparse
import os
from datetime import datetime

# ------------------------------
# Parse command line arguments
# ------------------------------
parser = argparse.ArgumentParser(description='Golf Ball Tracking with Auto-Calibration')
parser.add_argument('--auto', action='store_true', help='Enable automatic HSV calibration')
parser.add_argument('--save_frames', action='store_true', help='Save debug frames for report')
parser.add_argument('--ball_color', default='white', choices=['white', 'yellow', 'orange'], 
                    help='Color of the golf ball to track')
args = parser.parse_args()

# Directory for saving debug frames
DEBUG_DIR = "debug_frames"
if args.save_frames and not os.path.exists(DEBUG_DIR):
    os.makedirs(DEBUG_DIR)

# ------------------------------
# 1) Trackbar setup for manual HSV calibration
# ------------------------------
def nothing(x):
    pass

cv2.namedWindow("Trackbars")

# Initialize HSV ranges based on ball color
if args.ball_color == 'white':
    # For white balls - low saturation, high value. Robust to lighting changes.
    init_l_h, init_l_s, init_l_v = 0, 0, 180 # Initial Lower HSV for White
    init_u_h, init_u_s, init_u_v = 179, 50, 255 # Initial Upper HSV for White
elif args.ball_color == 'yellow':
    # For yellow balls - specific hue, good saturation and value.
    init_l_h, init_l_s, init_l_v = 20, 100, 100 # Initial Lower HSV for Yellow
    init_u_h, init_u_s, init_u_v = 35, 255, 255 # Initial Upper HSV for Yellow
elif args.ball_color == 'orange':
    # For orange balls - specific hue, good saturation and value.
    init_l_h, init_l_s, init_l_v = 5, 100, 100  # Initial Lower HSV for Orange
    init_u_h, init_u_s, init_u_v = 20, 255, 255  # Initial Upper HSV for Orange
else:
    # Default values (e.g., for a generic bright object or if color not specified by arg choices)
    # These were originally for a tennis ball; may not be ideal for golf balls.
    init_l_h, init_l_s, init_l_v = 35, 51, 150
    init_u_h, init_u_s, init_u_v = 109, 153, 255

cv2.createTrackbar("L - H", "Trackbars", init_l_h, 179, nothing)
cv2.createTrackbar("L - S", "Trackbars", init_l_s, 255, nothing)
cv2.createTrackbar("L - V", "Trackbars", init_l_v, 255, nothing)
cv2.createTrackbar("U - H", "Trackbars", init_u_h, 179, nothing)
cv2.createTrackbar("U - S", "Trackbars", init_u_s, 255, nothing)
cv2.createTrackbar("U - V", "Trackbars", init_u_v, 255, nothing)
cv2.createTrackbar("Auto Mode", "Trackbars", 1 if args.auto else 0, 1, nothing)

# ------------------------------
# Auto-calibration parameters
# ------------------------------
# History of successful detections for stabilization
detection_history = []
MAX_HISTORY = 10 # Max number of historical detection states to consider (not actively used in current logic but can be for stability)
# Threshold for minimum contour area to be considered a potential ball (pixels^2)
# This helps filter out small noise or irrelevant detections.
MIN_BALL_AREA = 100  # Heuristic, adjust based on camera resolution and expected ball size in frame.
# Whether we're currently in auto-adjustment mode (can be toggled by trackbar/key)
auto_adjusting = args.auto # Retained for potential future use; primary toggle is auto_mode from trackbar
# Counters for adaptation process if ball is not detected
frames_since_detection = 0 # Number of consecutive frames without a ball detection
MAX_FRAMES_BEFORE_ADAPT = 30 # After this many frames without detection, trigger adaptive search
# Amount to adjust HSV values by when auto-calibrating adaptively
HLSV_ADJUSTMENT_STEP = 5 # Heuristic step size for expanding/contracting HSV ranges
# Flag indicating if initial auto-calibration has found the ball at least once
autocal_success = False # Used to switch from broad search to refinement

# ------------------------------
# 2) Video capture setup
# ------------------------------
def list_available_cameras(max_to_check=5):
    """List all available camera indices and let user choose one."""
    available_cameras = []
    for i in range(max_to_check): 
        try:
            # Use DirectShow backend which is better for specialized cameras
            cap = cv2.VideoCapture(i, cv2.CAP_DSHOW)
            if cap.isOpened():
                ret, _ = cap.read()
                if ret:
                    # Store additional information about the camera
                    available_cameras.append({
                        'index': i,
                        'resolution': (int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)), 
                                      int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))),
                        'fps': cap.get(cv2.CAP_PROP_FPS)
                    })
            cap.release()
            time.sleep(0.1)  # Shorter sleep time is sufficient
        except Exception as e:
            print(f"Error checking camera {i}: {str(e)}")
    return available_cameras

# List available cameras
print("Searching for available cameras...")
available_cameras = list_available_cameras()
if not available_cameras:
    print("No cameras found! Please check if your webcam is connected and not in use by another application.")
    print("You might need to:")
    print("1. Close other applications that might be using the webcam")
    print("2. Check if the webcam is properly connected")
    print("3. Check Windows privacy settings to allow camera access")
    exit()

print("\nAvailable cameras:")
for i, camera in enumerate(available_cameras):
    print(f"  Camera {i+1}:")
    print(f"    Index: {camera['index']}")
    print(f"    Resolution: {camera['resolution'][0]}x{camera['resolution'][1]}")
    print(f"    FPS: {camera['fps']}")

# Let user choose camera
while True:
    try:
        user_choice = int(input("\nEnter the camera number (1-{0}): ".format(len(available_cameras))))
        if 1 <= user_choice <= len(available_cameras):
            camera_idx = available_cameras[user_choice-1]['index']
            break
        else:
            print(f"Invalid choice. Please enter a number between 1 and {len(available_cameras)}")
    except ValueError:
        print("Please enter a valid number")

# Initialize camera using DirectShow backend
print(f"\nTrying to open camera {camera_idx}...")
cap = cv2.VideoCapture(camera_idx, cv2.CAP_DSHOW)

# Set camera properties
cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)

if not cap.isOpened():
    print("Error: Could not open selected camera.")
    print("Please try:")
    print("1. Disconnecting and reconnecting your webcam")
    print("2. Restarting your computer")
    print("3. Checking Windows Device Manager for webcam issues")
    exit()

print("Camera opened successfully!")
print("Press 'q' to quit, 'a' to toggle auto-calibration, 's' to save current frame")

# ------------------------------
# 3) Auto-calibration functions
# ------------------------------
def analyze_lighting(frame):
    """Analyze the lighting conditions in the frame to guide HSV adjustments."""
    # Convert to grayscale for brightness analysis
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    # Calculate average brightness (0-255). Higher means brighter overall scene.
    avg_brightness = np.mean(gray)
    # Calculate histogram for brightness distribution (not directly used in current logic but useful for advanced analysis)
    hist = cv2.calcHist([gray], [0], None, [256], [0, 256])
    # Find percentage of very bright pixels (e.g., >200) which might indicate glare or very bright sky.
    _, bright_mask = cv2.threshold(gray, 200, 255, cv2.THRESH_BINARY)
    bright_percent = (cv2.countNonZero(bright_mask) / (frame.shape[0] * frame.shape[1])) * 100
    
    return {
        'avg_brightness': avg_brightness,
        'histogram': hist,
        'bright_percent': bright_percent
    }

def adjust_hsv_for_lighting(light_info, ball_color):
    """
    Return recommended HSV adjustments based on lighting analysis and ball color.
    This function contains heuristic rules based on observed behavior.
    Args:
        light_info (dict): Output from analyze_lighting().
        ball_color (str): Color of the ball ('white', 'yellow', 'orange').
    Returns:
        dict: Recommended HSV values {l_h, l_s, l_v, u_h, u_s, u_v}.
    """
    brightness = light_info['avg_brightness']
    bright_percent = light_info['bright_percent']
    
    # Base initial values from command line / defaults
    base_hsv = {
        'l_h': init_l_h, 'l_s': init_l_s, 'l_v': init_l_v,
        'u_h': init_u_h, 'u_s': init_u_s, 'u_v': init_u_v
    }

    if ball_color == 'white':
        # For white balls, Value (brightness) is key. Saturation should be low.
        if brightness < 80:  # Darker environment
            # Lower the minimum Value, allow slightly higher Saturation
            base_hsv['l_v'] = max(150, init_l_v - 50)
            base_hsv['u_s'] = min(80, init_u_s + 30) 
        elif brightness > 180 or bright_percent > 25:  # Very bright (potential glare/washout)
            # Increase minimum Value, tighten (lower) max Saturation to reject bright non-white areas
            base_hsv['l_v'] = min(235, init_l_v + 35) 
            base_hsv['u_s'] = max(10, init_u_s - 20)
        # else: use initial seed values for moderate lighting
        return base_hsv
    
    elif ball_color == 'yellow':
        # For yellow balls, Hue is critical. Saturation and Value need to be strong.
        if brightness < 80:  # Darker environment
            # Lower min Saturation and Value thresholds
            base_hsv['l_s'] = max(80, init_l_s - 20)
            base_hsv['l_v'] = max(80, init_l_v - 20)
        elif brightness > 180: # Brighter environment
            # Increase min Saturation and Value thresholds
            base_hsv['l_s'] = min(150, init_l_s + 50)
            base_hsv['l_v'] = min(150, init_l_v + 50)
        return base_hsv
    
    elif ball_color == 'orange':
        # Similar logic for orange as for yellow.
        if brightness < 80:
            base_hsv['l_s'] = max(80, init_l_s - 20)
            base_hsv['l_v'] = max(80, init_l_v - 20)
        elif brightness > 180:
            base_hsv['l_s'] = min(150, init_l_s + 50)
            base_hsv['l_v'] = min(150, init_l_v + 50)
        return base_hsv
    
    # Default: return initial seed values if color not handled above
    return base_hsv

def adaptive_search(hsv_values, frame, direction='expand'):
    """
    Adaptively search for the ball by adjusting HSV values if not found.
    'expand': Broadens HSV ranges to find a lost ball.
    'contract': Tightens HSV ranges if too many/noisy detections occur (not fully implemented here).
    Args:
        hsv_values (dict): Current HSV thresholds.
        frame (numpy.ndarray): Current camera frame.
        direction (str): 'expand' or 'contract'.
    Returns:
        tuple: (new_hsv_values, search_completed_or_found_ball)
    """
    # Create a mask with current HSV values
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    lower_bound = np.array([hsv_values['l_h'], hsv_values['l_s'], hsv_values['l_v']])
    upper_bound = np.array([hsv_values['u_h'], hsv_values['u_s'], hsv_values['u_v']])
    
    mask = cv2.inRange(hsv, lower_bound, upper_bound)
    mask = cv2.erode(mask, None, iterations=2)
    mask = cv2.dilate(mask, None, iterations=2)
    
    # Find contours
    contours = cv2.findContours(mask.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    contours = imutils.grab_contours(contours)
    
    # Check if we found any significant contours
    good_contours = [c for c in contours if cv2.contourArea(c) > MIN_BALL_AREA]
    
    # If we found contours and we're in expand mode, it means we likely found the ball.
    if good_contours and direction == 'expand':
        return hsv_values, True # Search successful, ball found
    
    # If we're in contract mode and found too many contours (e.g., >3), we need to tighten the range.
    # This part aims to refine a noisy detection.
    if len(good_contours) > 3 and direction == 'contract':
        new_values = hsv_values.copy()
        # Heuristic: tighten by increasing lower S/V and decreasing upper S for white.
        if args.ball_color == 'white':
            new_values['l_v'] = min(255, hsv_values['l_v'] + HLSV_ADJUSTMENT_STEP)
            new_values['u_s'] = max(0, hsv_values['u_s'] - HLSV_ADJUSTMENT_STEP)
        else: # For colored balls
            new_values['l_s'] = min(255, hsv_values['l_s'] + HLSV_ADJUSTMENT_STEP)
            new_values['l_v'] = min(255, hsv_values['l_v'] + HLSV_ADJUSTMENT_STEP)
        print(f"Adaptive Search (Contract): Tightening HSV to {new_values}")
        return new_values, False # Search continues, refinement in progress
    
    # If we're in expand mode and found no contours, we need to broaden the range.
    if not good_contours and direction == 'expand':
        new_values = hsv_values.copy()
        # Heuristic: broaden by decreasing lower S/V and increasing upper S for white.
        if args.ball_color == 'white':
            new_values['l_v'] = max(100, hsv_values['l_v'] - HLSV_ADJUSTMENT_STEP) # Min V floor 100
            new_values['u_s'] = min(100, hsv_values['u_s'] + HLSV_ADJUSTMENT_STEP) # Max S ceiling 100
        else: # For colored balls
            new_values['l_s'] = max(30, hsv_values['l_s'] - HLSV_ADJUSTMENT_STEP) # Min S floor 30
            new_values['l_v'] = max(30, hsv_values['l_v'] - HLSV_ADJUSTMENT_STEP) # Min V floor 30
        print(f"Adaptive Search (Expand): Broadening HSV to {new_values}")
        return new_values, False # Search continues, range expanded
    
    # Default case: If in 'contract' mode and few/no contours, or other unhandled state.
    return hsv_values, True # Assume search is stable or complete for current state.

def save_debug_frame(frame, mask, hsv_values, frame_name=None):
    """Save current frame and mask for debugging and report"""
    if not args.save_frames:
        return
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    if frame_name:
        base_name = f"{frame_name}"
    else:
        base_name = f"debug_{timestamp}"
    
    # Create a side-by-side view
    mask_colored = cv2.cvtColor(mask, cv2.COLOR_GRAY2BGR)
    combined = np.hstack((frame, mask_colored))
    
    # Add HSV values text
    hsv_text = f"HSV: L({hsv_values['l_h']},{hsv_values['l_s']},{hsv_values['l_v']}) U({hsv_values['u_h']},{hsv_values['u_s']},{hsv_values['u_v']})"
    cv2.putText(combined, hsv_text, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)
    
    # Save the combined image
    cv2.imwrite(os.path.join(DEBUG_DIR, f"{base_name}.jpg"), combined)
    print(f"Saved debug frame: {base_name}.jpg")

# ------------------------------
# 4) Additional Variables
# ------------------------------
previous_positions = [] # Stores (x,y) screen coordinates of detected ball for trail
# TODO: CRITICAL - Calibrate pixels_per_meter accurately!
# This value depends on camera intrinsics, lens, and distance to the measurement plane.
# For PoC, it's a rough estimate. For real speed, it needs to be precise.
pixels_per_meter = 100  # Example: 100 pixels on screen = 1 meter in real world at a certain depth.
smoothed_x, smoothed_y = None, None  # For optional Kalman filter or simple EMA smoothing of ball center

# We'll measure actual FPS instead of hardcoding frame_rate
prev_time = time.time()
frame_count = 0
fps_update_interval = 10  # Update FPS every 10 frames
total_time = 0

# Auto calibration current values
current_hsv = {
    'l_h': init_l_h, 'l_s': init_l_s, 'l_v': init_l_v,
    'u_h': init_u_h, 'u_s': init_u_s, 'u_v': init_u_v
}

# ------------------------------
# 5) Main Loop
# ------------------------------
while True:
    # Calculate FPS every few frames for stability
    current_time = time.time()
    dt = current_time - prev_time
    total_time += dt
    prev_time = current_time
    frame_count += 1
    
    if frame_count % fps_update_interval == 0:
        actual_fps = fps_update_interval / total_time
        total_time = 0
    
    # Read a frame
    ret, frame = cap.read()
    if not ret:
        print("Failed to grab frame")
        break
    
    # Make a copy for annotation
    original_frame = frame.copy()

    # Resize for consistency
    frame = imutils.resize(frame, width=800)
    
    # Check if auto mode is enabled via trackbar
    auto_mode = cv2.getTrackbarPos("Auto Mode", "Trackbars") == 1
    
    # In auto mode, analyze lighting and adjust HSV values
    if auto_mode:
        # 1. Analyze current lighting conditions in the frame.
        lighting_info = analyze_lighting(frame)
        
        # 2. Get recommended HSV values based on lighting and selected ball color.
        # These are target values; the system will gradually move towards them if detection is stable.
        recommended_hsv = adjust_hsv_for_lighting(lighting_info, args.ball_color)
        
        # 3. Adaptive Search / Adjustment Logic:
        # If the ball hasn't been detected for MAX_FRAMES_BEFORE_ADAPT, trigger adaptive search.
        if frames_since_detection > MAX_FRAMES_BEFORE_ADAPT:
            if not autocal_success:
                # Stage 1 of AutoCal: Expand HSV range to find the ball if lost.
                print(f"No detection for {frames_since_detection} frames. Expanding HSV search...")
                new_hsv, search_complete = adaptive_search(current_hsv, frame, 'expand')
                if search_complete and new_hsv != current_hsv:
                    print("Auto-calibration (Expand phase) found potential ball. HSV values adjusted.")
                    # Optional: save frame when auto-cal completes an adjustment step
                    # save_debug_frame(frame, cv2.inRange(...), new_hsv, "auto_cal_expand_found")
                    autocal_success = True # Mark that initial broad search phase found something.
                current_hsv = new_hsv
            elif frames_since_detection > MAX_FRAMES_BEFORE_ADAPT * 2: # Allow more time before trying to contract
                # Stage 2 of AutoCal (Conceptual): If still issues or too many detections, try to contract/refine.
                # This part of logic might need more sophisticated handling.
                print(f"Detection still unstable after expand. Attempting to contract/refine HSV...")
                new_hsv, _ = adaptive_search(current_hsv, frame, 'contract') # Attempt to tighten
                current_hsv = new_hsv
                # Reset frames_since_detection to give contract phase time to work, or manage state differently
                # frames_since_detection = 0 
        else:
            # If ball is being detected consistently, gradually tween current_hsv towards recommended_hsv.
            # This provides smooth adaptation to slow lighting changes.
            autocal_success = False # Reset autocal success if detection is stable, allowing re-trigger of expand if lost again
            for key in current_hsv:
                # Simple tweening: move 1 step towards recommended value per frame.
                if current_hsv[key] < recommended_hsv[key]:
                    current_hsv[key] = min(recommended_hsv[key], current_hsv[key] + 1)
                elif current_hsv[key] > recommended_hsv[key]:
                    current_hsv[key] = max(recommended_hsv[key], current_hsv[key] - 1)
        
        # Update trackbars to show current auto values
        cv2.setTrackbarPos("L - H", "Trackbars", current_hsv['l_h'])
        cv2.setTrackbarPos("L - S", "Trackbars", current_hsv['l_s'])
        cv2.setTrackbarPos("L - V", "Trackbars", current_hsv['l_v'])
        cv2.setTrackbarPos("U - H", "Trackbars", current_hsv['u_h'])
        cv2.setTrackbarPos("U - S", "Trackbars", current_hsv['u_s'])
        cv2.setTrackbarPos("U - V", "Trackbars", current_hsv['u_v'])
    else:
        # In manual mode, read values from trackbars
        current_hsv['l_h'] = cv2.getTrackbarPos("L - H", "Trackbars")
        current_hsv['l_s'] = cv2.getTrackbarPos("L - S", "Trackbars")
        current_hsv['l_v'] = cv2.getTrackbarPos("L - V", "Trackbars")
        current_hsv['u_h'] = cv2.getTrackbarPos("U - H", "Trackbars")
        current_hsv['u_s'] = cv2.getTrackbarPos("U - S", "Trackbars")
        current_hsv['u_v'] = cv2.getTrackbarPos("U - V", "Trackbars")
    
    # Use the current HSV values to create mask
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    LOWER_COLOR = (current_hsv['l_h'], current_hsv['l_s'], current_hsv['l_v'])
    UPPER_COLOR = (current_hsv['u_h'], current_hsv['u_s'], current_hsv['u_v'])
    
    # Threshold the image
    mask = cv2.inRange(hsv, LOWER_COLOR, UPPER_COLOR)
    mask = cv2.erode(mask, None, iterations=2)
    mask = cv2.dilate(mask, None, iterations=2)
    
    # Find contours
    contours = cv2.findContours(mask.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    contours = imutils.grab_contours(contours)
    
    # Filter contours by area
    contours = [c for c in contours if cv2.contourArea(c) > MIN_BALL_AREA]
    
    # --------------------------------------------
    # 6) Improved ball detection with circularity
    # --------------------------------------------
    ball_detected = False
    
    if contours:
        # If multiple contours, find the most circular one that's big enough
        best_contour = None
        best_circularity = 0
        
        for c in contours:
            # Calculate circularity (1.0 is a perfect circle)
            area = cv2.contourArea(c)
            perimeter = cv2.arcLength(c, True)
            circularity = 4 * np.pi * area / (perimeter * perimeter) if perimeter > 0 else 0
            
            # Weighted score - prefer larger, more circular contours
            weighted_score = circularity * (area / 1000)
            
            if weighted_score > best_circularity:
                best_circularity = weighted_score
                best_contour = c
        
        # Only proceed if we found a good candidate and it's circular enough
        if best_contour is not None and best_circularity > 0.5:
            c = best_contour
            ((x, y), radius) = cv2.minEnclosingCircle(c)
            
            # Only proceed if the radius is large enough
            if radius > 5:
                ball_detected = True
                frames_since_detection = 0  # Reset counter when we detect the ball
                
                # Optional: apply a simple smoothing filter
                if smoothed_x is None or smoothed_y is None:
                    smoothed_x, smoothed_y = x, y
                else:
                    alpha = 0.5  # Smoothing factor
                    smoothed_x = alpha * x + (1 - alpha) * smoothed_x
                    smoothed_y = alpha * y + (1 - alpha) * smoothed_y
                
                # Draw the circle for visual reference
                cv2.circle(frame, (int(smoothed_x), int(smoothed_y)), int(radius), (0, 255, 0), 2)
                
                # Keep track of positions (use the smoothed values)
                previous_positions.append((smoothed_x, smoothed_y))
                
                # Limit length of stored positions
                if len(previous_positions) > 10:
                    previous_positions.pop(0)
                
                # Draw motion trail
                for i in range(1, len(previous_positions)):
                    if previous_positions[i - 1] is None or previous_positions[i] is None:
                        continue
                    pt1 = (int(previous_positions[i - 1][0]), int(previous_positions[i - 1][1]))
                    pt2 = (int(previous_positions[i][0]), int(previous_positions[i][1]))
                    cv2.line(frame, pt1, pt2, (255, 0, 0), 2)
                
                # ------------------------------
                # 7) Speed Calculation 
                # ------------------------------
                if len(previous_positions) > 1:
                    x1, y1 = previous_positions[-2]
                    x2, y2 = previous_positions[-1]
                    distance_px = np.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)
                    distance_m = distance_px / pixels_per_meter
                    # Speed in meters per second (using actual_fps measured from frame rate)
                    # Accuracy highly depends on calibrated `pixels_per_meter` and stable `actual_fps`.
                    speed_mps = distance_m * actual_fps if actual_fps > 0 else 0 # Avoid division by zero if fps is not ready
                    speed_mph = speed_mps * 2.23694  # Convert from m/s to mph
                    
                    cv2.putText(frame, f"Speed: {speed_mph:.2f} mph ({speed_mps:.2f} m/s)", (50, 50),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
    
    if not ball_detected:
        frames_since_detection += 1
    
    # ---------------------------------------------
    # 8) Display information and debug overlay
    # ---------------------------------------------
    # Display FPS and mode
    cv2.putText(frame, f"FPS: {actual_fps:.2f}", (50, 80),
                cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 0), 2)
    
    mode_text = "AUTO" if auto_mode else "MANUAL"
    cv2.putText(frame, f"Mode: {mode_text}", (50, 110),
                cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 0), 2)
    
    # Display lighting information
    if auto_mode:
        lighting_info = analyze_lighting(frame)
        cv2.putText(frame, f"Brightness: {lighting_info['avg_brightness']:.1f}", (50, 140),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 0), 2)
        cv2.putText(frame, f"Bright %: {lighting_info['bright_percent']:.1f}%", (50, 170),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 0), 2)
    
    # Display current HSV values
    hsv_text = f"HSV: L({current_hsv['l_h']},{current_hsv['l_s']},{current_hsv['l_v']}) U({current_hsv['u_h']},{current_hsv['u_s']},{current_hsv['u_v']})"
    cv2.putText(frame, hsv_text, (50, 200), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 255), 1)
    
    # Create a side-by-side view
    mask_colored = cv2.cvtColor(mask, cv2.COLOR_GRAY2BGR)  # Convert mask to 3-channel
    combined_view = np.hstack((frame, mask_colored))  # Stack horizontally
    
    # Show the combined view
    cv2.imshow("Original and Mask View", combined_view)
    
    # Key handling
    key = cv2.waitKey(1) & 0xFF
    if key == ord('q'):
        break
    elif key == ord('a'):
        # Toggle auto mode
        auto_mode = not auto_mode
        cv2.setTrackbarPos("Auto Mode", "Trackbars", 1 if auto_mode else 0)
        print(f"Auto mode {'enabled' if auto_mode else 'disabled'}")
    elif key == ord('s'):
        # Save current frame for debugging/reporting
        save_debug_frame(frame, mask, current_hsv, f"manual_save_{datetime.now().strftime('%Y%m%d_%H%M%S')}")

# Clean up
cap.release()
cv2.destroyAllWindows()
print("Application closed.") 